# VisionAdapt — produto e monetização

## Modelo atual

### Gratuito

- iniciar/encerrar sessão;
- ajuste manual;
- A/B cego;
- memória perceptiva local;
- desfazer/restaurar;
- navegador adaptativo HTTPS.

### Premium

- assistência contextual;
- microajustes contextuais;
- botão flutuante sobre outros apps;
- ampliação global;
- redução luminosa global.

## Google Play Billing

Biblioteca: `com.android.billingclient:billing:9.1.0`

Produto esperado:

`visionadapt_premium_monthly`

Oferta preferida:

`visionadapt_default`

O motor procura primeiro uma oferta com essa tag. Se ela não existir, usa a primeira oferta retornada pelo Google Play.

## Trial

O trial local de 7 dias existe **somente no build debug**, para que seja possível testar o Premium antes do Play Console estar configurado.

No build release:

- limpar dados do app não recria acesso Premium;
- o trial local não concede acesso;
- trials/ofertas devem ser configurados no Google Play.

## Entitlement

O app atualiza compras ao abrir/retomar a tela principal e mantém um cache local verificado por até 7 dias para evitar acesso Premium indefinido sem nova checagem. Para escala comercial, a verificação deve migrar para backend seguro usando os tokens de compra do Google Play.

## Receita

O código não fixa preço. O valor exibido é carregado do Google Play e pode variar por país/oferta.
