# VisionAdapt 1.0.0-rc1 — escopo real

## O que já existe

1. Sessão visual explicitamente iniciada e encerrada pelo usuário.
2. Perfil persistente com tamanho, espaçamento de letras, espaçamento de linhas, contraste e luminosidade.
3. Busca perceptual A/B cega, uma variável por vez, com refinamento progressivo.
4. Memória por eixo do que ajudou e do que não ajudou.
5. Desfazer e restauração do início da sessão.
6. Navegador adaptativo HTTPS com WebView endurecida e transformação reversível por CSS.
7. Contexto de sessão com tempo, correções recentes, horário e sensor de luz ambiente em lux.
8. Sugestões contextuais reversíveis; não são diagnóstico médico.
9. Serviço opcional de acessibilidade para botão flutuante, ampliação do sistema e redução luminosa.
10. Núcleo gratuito e Premium integrado ao Google Play Billing.
11. Onboarding, privacidade, reset de aprendizado e estados de erro principais.
12. Configuração Play-ready API 36 e configuração separada de compatibilidade AndroidIDE.

## O que o app não deve prometer nesta versão

- corrigir miopia/astigmatismo de forma equivalente a uma lente;
- modificar livremente os pixels internos de qualquer outro app;
- diagnosticar fadiga/cansaço ocular;
- medir acuidade visual clínica;
- substituir consulta ou prescrição oftalmológica.

## Próxima geração tecnológica possível

A evolução mais importante depois desta versão é um renderer próprio para imagem/vídeo com transformações espaciais mais profundas e calibração visual individual. Isso exige pesquisa adicional e deve ser tratado separadamente da experiência já funcional deste RC.
