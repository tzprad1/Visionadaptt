from pathlib import Path
import re, sys, xml.etree.ElementTree as ET
root = Path(__file__).resolve().parents[1]
errors=[]

def need(cond, msg):
    if not cond: errors.append(msg)

# XML validity
for p in (root/'app/src/main/res').rglob('*.xml'):
    try: ET.parse(p)
    except Exception as e: errors.append(f'XML inválido {p.relative_to(root)}: {e}')
try: ET.parse(root/'app/src/main/AndroidManifest.xml')
except Exception as e: errors.append(f'Manifest inválido: {e}')

app_gradle=(root/'app/build.gradle').read_text()
root_gradle=(root/'build.gradle').read_text()
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
svc=(root/'app/src/main/res/xml/vision_accessibility_service.xml').read_text()
billing=(root/'app/src/main/java/com/visionadapt/mobile/BillingManager.java').read_text()

need('compileSdk 36' in app_gradle, 'compileSdk precisa ser 36')
need('targetSdk 36' in app_gradle, 'targetSdk precisa ser 36')
need('com.visionadapt.mobile' in app_gradle, 'applicationId de release ausente')
need('namespace \'com.visionadapt.mobile\'' in app_gradle, 'namespace final ausente')
need('8.13.2' in root_gradle, 'AGP 8.13.2 ausente')
need('billing:9.1.0' in app_gradle, 'Billing 9.1.0 ausente')
need('DEV_LOCAL_PREMIUM_TRIAL", "false"' in app_gradle, 'trial local precisa estar desligado no release')
need('android:allowBackup="false"' in manifest, 'backup precisa permanecer desativado')
need('android:usesCleartextTraffic="false"' in manifest, 'cleartext precisa permanecer desativado')
need('android:canRetrieveWindowContent="false"' in svc, 'serviço não deve recuperar conteúdo de janelas')
need('android:isAccessibilityTool="true"' in svc, 'flag de ferramenta de acessibilidade ausente')
need('visionadapt_premium_monthly' in billing, 'ID do produto Premium ausente')
need('visionadapt_default' in billing, 'tag de oferta preferida ausente')
need((root/'.github/workflows/android-build.yml').exists(), 'workflow de build ausente')
need((root/'androidide-compat/README.md').exists(), 'modo AndroidIDE ausente')

# Ensure no accidental dangerous WebView bridge was added.
all_java='\n'.join(p.read_text(errors='ignore') for p in (root/'app/src/main/java').rglob('*.java'))
need('addJavascriptInterface' not in all_java, 'WebView não deve expor addJavascriptInterface nesta versão')

if errors:
    print('FINAL STATIC CHECKS: FAIL')
    for e in errors: print('-',e)
    sys.exit(1)
print('FINAL STATIC CHECKS: PASS')
