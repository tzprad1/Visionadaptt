#!/usr/bin/env sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
OUT="${TMPDIR:-/tmp}/visionadapt-core-test"
rm -rf "$OUT"
mkdir -p "$OUT"
javac -d "$OUT" \
  "$ROOT/app/src/main/java/com/visionadapt/mobile/VisionProfile.java" \
  "$ROOT/app/src/main/java/com/visionadapt/mobile/VisionSession.java" \
  "$ROOT/app/src/main/java/com/visionadapt/mobile/VisionRuntime.java" \
  "$ROOT/app/src/main/java/com/visionadapt/mobile/VisionTuningEngine.java" \
  "$ROOT/app/src/main/java/com/visionadapt/mobile/VisionContextState.java" \
  "$ROOT/app/src/main/java/com/visionadapt/mobile/VisionContextEngine.java" \
  "$ROOT/app/src/main/java/com/visionadapt/mobile/MonetizationPolicy.java" \
  "$ROOT/tools/CoreSmokeTest.java"
java -cp "$OUT" CoreSmokeTest
