import com.visionadapt.mobile.VisionProfile;
import com.visionadapt.mobile.VisionRuntime;
import com.visionadapt.mobile.VisionContextState;
import com.visionadapt.mobile.VisionContextEngine;
import com.visionadapt.mobile.VisionSession;
import com.visionadapt.mobile.VisionTuningEngine;
import com.visionadapt.mobile.MonetizationPolicy;

public class CoreSmokeTest {
    public static void main(String[] args) {
        testBoundsUnderLongTraining();
        testRejectionFlipsDirection();
        testSecondRejectionAdvancesAxis();
        testNegativeLearnedDirectionStillFlipsOnReject();
        testAllAxisBoundarySearchNeverReturnsIdentical();
        testAcceptanceAppliesCandidateAndLearnsDirection();
        testSameAdvancesWithoutChangingPresentation();
        testBoundaryProposalIsStillUseful();
        testManualEditKeepsLearning();
        testLearnedDirectionIsReusedOnNextAxis();
        testLearningEvidenceByAxis();
        testSessionLifecycle();
        testSessionCheckpointUndo();
        testSessionStartSnapshotIsIndependent();
        testUndoHistoryIsBounded();
        testExternalEffectBounds();
        testExternalEffectsCopyAndRestore();
        testContextSignalFreshness();
        testContextCorrectionWindow();
        testContextLoadAndProposal();
        testContextLearningResponse();
        testExternalContextProposalIsVisible();
        testContextDisabledBlocksProposal();
        testContextStressBounds();
        testPremiumTrialPolicy();
        testPremiumAlwaysWins();
        System.out.println("VisionAdapt final core smoke test: PASS");
    }

    private static void testBoundsUnderLongTraining() {
        VisionProfile p = new VisionProfile();
        for (int i = 0; i < 500; i++) {
            VisionTuningEngine.Proposal proposal = VisionTuningEngine.nextProposal(p);
            VisionTuningEngine.Response response;
            if (i % 5 == 0 || i % 5 == 3) response = VisionTuningEngine.Response.BETTER;
            else if (i % 5 == 1) response = VisionTuningEngine.Response.WORSE;
            else response = VisionTuningEngine.Response.SAME;
            VisionTuningEngine.respond(p, proposal, response);
            assertBounds(p);
        }
        require(p.totalComparisons() == 500, "all comparisons accounted for");
    }

    private static void testRejectionFlipsDirection() {
        VisionProfile p = new VisionProfile();
        p.tuneAxis = 0;
        p.tuneDirection = 1;
        VisionTuningEngine.Proposal first = VisionTuningEngine.nextProposal(p);
        require(first.axis == VisionTuningEngine.Axis.FONT_SCALE, "first axis font");
        require(first.delta > 0f, "first direction positive");
        VisionTuningEngine.respond(p, first, VisionTuningEngine.Response.WORSE);
        VisionTuningEngine.Proposal second = VisionTuningEngine.nextProposal(p);
        require(second.axis == VisionTuningEngine.Axis.FONT_SCALE, "same axis after first rejection");
        require(second.delta < 0f, "opposite direction after rejection");
    }

    private static void testSecondRejectionAdvancesAxis() {
        VisionProfile p = new VisionProfile();
        VisionTuningEngine.Proposal plus = VisionTuningEngine.nextProposal(p);
        VisionTuningEngine.respond(p, plus, VisionTuningEngine.Response.WORSE);
        VisionTuningEngine.Proposal minus = VisionTuningEngine.nextProposal(p);
        VisionTuningEngine.respond(p, minus, VisionTuningEngine.Response.WORSE);
        require(p.tuneAxis == 1, "axis advances after both directions reject");
    }


    private static void testNegativeLearnedDirectionStillFlipsOnReject() {
        VisionProfile p = new VisionProfile();
        p.tuneAxis = 0;
        p.preferredDirection[0] = -1;
        p.tuneDirection = -1;
        VisionTuningEngine.Proposal first = VisionTuningEngine.nextProposal(p);
        require(first.direction == -1, "learned negative direction used first");
        VisionTuningEngine.respond(p, first, VisionTuningEngine.Response.WORSE);
        VisionTuningEngine.Proposal second = VisionTuningEngine.nextProposal(p);
        require(second.axis == VisionTuningEngine.Axis.FONT_SCALE, "negative rejection remains on same axis");
        require(second.direction == 1 && second.delta > 0f, "negative rejection flips to positive");
    }

    private static void testAllAxisBoundarySearchNeverReturnsIdentical() {
        VisionProfile p = new VisionProfile();
        p.fontScale = 1.70f;
        p.letterSpacingEm = 0.18f;
        p.lineHeight = 2.20f;
        p.contrast = 1.60f;
        p.brightness = 1.35f;
        p.tuneAxis = 0;
        p.tuneDirection = 1;
        VisionTuningEngine.Proposal proposal = VisionTuningEngine.nextProposal(p);
        require(VisionTuningEngine.presentationDiffers(proposal.baseline, proposal.candidate),
            "boundary search still produces a visible comparison");
    }

    private static void testAcceptanceAppliesCandidateAndLearnsDirection() {
        VisionProfile p = new VisionProfile();
        VisionTuningEngine.Proposal proposal = VisionTuningEngine.nextProposal(p);
        float before = p.fontScale;
        VisionTuningEngine.respond(p, proposal, VisionTuningEngine.Response.BETTER);
        require(p.fontScale != before, "accepted candidate changes presentation");
        require(p.acceptedAdjustments == 1, "acceptance counter");
        require(p.axisBetter[0] == 1, "axis win learned");
        require(p.preferredDirection[0] == proposal.direction, "direction preference learned");
    }

    private static void testSameAdvancesWithoutChangingPresentation() {
        VisionProfile p = new VisionProfile();
        VisionProfile before = p.copy();
        VisionTuningEngine.Proposal proposal = VisionTuningEngine.nextProposal(p);
        VisionTuningEngine.respond(p, proposal, VisionTuningEngine.Response.SAME);
        require(equalPresentation(p, before), "same response does not alter presentation");
        require(p.tuneAxis == 1, "same response advances axis");
        require(p.neutralAdjustments == 1, "same counter");
        require(p.axisSame[0] == 1, "axis neutral evidence");
    }

    private static void testBoundaryProposalIsStillUseful() {
        VisionProfile p = new VisionProfile();
        p.fontScale = 1.70f;
        p.tuneAxis = 0;
        p.tuneDirection = 1;
        VisionTuningEngine.Proposal proposal = VisionTuningEngine.nextProposal(p);
        require(proposal.delta < 0f, "at upper bound engine automatically tries useful direction");
        require(proposal.candidate.fontScale < p.fontScale, "boundary proposal differs");
    }

    private static void testManualEditKeepsLearning() {
        VisionProfile p = new VisionProfile();
        p.fontScale = 1.22f;
        p.acceptedAdjustments = 7;
        p.preferredDirection[0] = -1;
        p.axisBetter[0] = 4;
        p.tuneAxis = 4;
        p.tuneDirection = -1;
        p.tunePrecision = 3;
        p.tuneAttemptsOnAxis = 2;
        VisionTuningEngine.onManualEdit(p);
        require(Math.abs(p.fontScale - 1.22f) < 0.0001f, "manual reset preserves presentation");
        require(p.acceptedAdjustments == 7, "manual reset preserves history counters");
        require(p.axisBetter[0] == 4, "manual reset preserves axis evidence");
        require(p.tuneAxis == 0 && p.tuneDirection == -1 && p.tunePrecision == 0,
            "manual reset restarts search using learned direction");
    }

    private static void testLearnedDirectionIsReusedOnNextAxis() {
        VisionProfile p = new VisionProfile();
        p.tuneAxis = 1;
        p.preferredDirection[2] = -1;
        VisionTuningEngine.Proposal proposal = VisionTuningEngine.nextProposal(p);
        require(proposal.axis == VisionTuningEngine.Axis.LETTER_SPACING, "setup axis");
        VisionTuningEngine.respond(p, proposal, VisionTuningEngine.Response.SAME);
        require(p.tuneAxis == 2, "advanced to line height");
        require(p.tuneDirection == -1, "remembered direction reused");
        VisionTuningEngine.Proposal next = VisionTuningEngine.nextProposal(p);
        require(next.axis == VisionTuningEngine.Axis.LINE_HEIGHT && next.delta < 0f,
            "next proposal follows learned direction");
    }

    private static void testLearningEvidenceByAxis() {
        VisionProfile p = new VisionProfile();
        VisionTuningEngine.Proposal proposal = VisionTuningEngine.nextProposal(p);
        VisionTuningEngine.respond(p, proposal, VisionTuningEngine.Response.WORSE);
        require(p.axisWorse[0] == 1, "rejection evidence stored on correct axis");
        require(p.evidenceForAxis(0) == 1, "axis evidence total");
        VisionProfile copy = p.copy();
        require(copy.axisWorse[0] == 1, "learning arrays copied");
    }

    private static void testSessionLifecycle() {
        VisionSession session = VisionRuntime.session();
        session.stop();
        require(!session.isActive(), "cold runtime starts off");
        VisionProfile start = new VisionProfile();
        start.fontScale = 1.19f;
        session.start(start);
        require(session.isActive(), "session start");
        require(session.canRestoreSessionStart(), "session start checkpoint available");
        session.stop();
        require(!session.isActive(), "session stop");
        require(!session.canUndo(), "stop clears undo");
    }

    private static void testSessionCheckpointUndo() {
        VisionSession session = VisionRuntime.session();
        session.stop();
        VisionProfile p = new VisionProfile();
        session.start(p);
        session.recordCheckpoint(p);
        p.fontScale = 1.30f;
        VisionProfile previous = session.popUndo();
        require(previous != null, "undo snapshot exists");
        require(Math.abs(previous.fontScale - 1.00f) < 0.0001f, "undo restores previous presentation");
        require(!session.canUndo(), "undo consumes checkpoint");
        session.stop();
    }

    private static void testSessionStartSnapshotIsIndependent() {
        VisionSession session = VisionRuntime.session();
        session.stop();
        VisionProfile p = new VisionProfile();
        p.fontScale = 1.10f;
        session.start(p);
        p.fontScale = 1.50f;
        VisionProfile start = session.getSessionStartProfile();
        require(start != null && Math.abs(start.fontScale - 1.10f) < 0.0001f,
            "session start is immutable snapshot");
        session.stop();
    }

    private static void testUndoHistoryIsBounded() {
        VisionSession session = VisionRuntime.session();
        session.stop();
        VisionProfile p = new VisionProfile();
        session.start(p);
        for (int i = 0; i < 20; i++) {
            p.fontScale = 0.80f + (i * 0.01f);
            session.recordCheckpoint(p);
        }
        require(session.undoDepth() == 12, "undo history capped at 12");
        session.stop();
    }

    private static void testExternalEffectBounds() {
        VisionProfile p = new VisionProfile();
        p.externalMagnification = 99f;
        p.externalDim = 3f;
        p.normalize();
        require(Math.abs(p.externalMagnification - 2.50f) < 0.0001f, "external magnification upper bound");
        require(Math.abs(p.externalDim - 0.60f) < 0.0001f, "external dim upper bound");
        p.externalMagnification = -4f;
        p.externalDim = -1f;
        p.normalize();
        require(Math.abs(p.externalMagnification - 1.00f) < 0.0001f, "external magnification lower bound");
        require(Math.abs(p.externalDim) < 0.0001f, "external dim lower bound");
    }

    private static void testExternalEffectsCopyAndRestore() {
        VisionProfile p = new VisionProfile();
        p.externalMagnification = 1.40f;
        p.externalDim = 0.20f;
        VisionProfile copy = p.copy();
        require(Math.abs(copy.externalMagnification - 1.40f) < 0.0001f, "external magnification copied");
        require(Math.abs(copy.externalDim - 0.20f) < 0.0001f, "external dim copied");

        VisionProfile target = new VisionProfile();
        target.adoptPresentationFrom(copy);
        require(Math.abs(target.externalMagnification - 1.40f) < 0.0001f, "external magnification restored");
        require(Math.abs(target.externalDim - 0.20f) < 0.0001f, "external dim restored");
    }

    private static void testContextSignalFreshness() {
        VisionContextState state = new VisionContextState();
        state.updateAmbientLux(18f, 1000L);
        require(state.hasFreshAmbientLux(2000L, 5000L), "fresh lux available");
        require(!state.hasFreshAmbientLux(7001L, 5000L), "stale lux expires");
        require(Math.abs(state.getAmbientLux() - 18f) < 0.0001f, "lux value stored");
    }

    private static void testContextCorrectionWindow() {
        VisionSession session = VisionRuntime.session();
        session.stop();
        session.start(new VisionProfile());
        long base = session.getStartedAtMs();
        session.noteUserCorrection(base + 1000L);
        session.noteUserCorrection(base + 2000L);
        require(session.recentCorrectionCount(base + 3000L, 10000L) == 2, "recent corrections counted");
        require(session.recentCorrectionCount(base + 20000L, 10000L) == 0, "old corrections pruned");
        session.stop();
    }

    private static void testContextLoadAndProposal() {
        VisionSession session = VisionRuntime.session();
        session.stop();
        VisionProfile p = new VisionProfile();
        session.start(p);
        long base = session.getStartedAtMs();
        VisionContextState state = new VisionContextState();
        state.updateAmbientLux(8f, base + 60L * 60L * 1000L);
        session.noteUserCorrection(base + 55L * 60L * 1000L);
        session.noteUserCorrection(base + 58L * 60L * 1000L);
        long now = base + 60L * 60L * 1000L;
        VisionContextEngine.Assessment a = VisionContextEngine.assess(p, session, state, now, 23);
        require(a.level != VisionContextEngine.LoadLevel.LOW, "context load elevated by multiple signals");
        require(a.lowLight, "low light detected contextually");
        require(a.recentCorrections == 2, "correction pressure preserved");
        VisionContextEngine.Proposal proposal = VisionContextEngine.nextProposal(p, session, state, now, 23);
        require(proposal != null, "context proposal created");
        require(VisionContextEngine.differs(proposal.baseline, proposal.candidate), "context proposal changes presentation");
        assertBounds(proposal.candidate);
        session.stop();
    }

    private static void testContextLearningResponse() {
        VisionProfile p = new VisionProfile();
        VisionContextEngine.respond(p, VisionContextEngine.Response.BETTER);
        VisionContextEngine.respond(p, VisionContextEngine.Response.WORSE);
        VisionContextEngine.respond(p, VisionContextEngine.Response.SAME);
        require(p.contextAccepted == 1, "context acceptance counted");
        require(p.contextRejected == 1, "context rejection counted");
        require(p.contextNeutral == 1, "context neutral counted");
        VisionProfile copy = p.copy();
        require(copy.contextAccepted == 1 && copy.contextRejected == 1 && copy.contextNeutral == 1,
            "context learning copied");
    }

    private static void testExternalContextProposalIsVisible() {
        VisionSession session = VisionRuntime.session();
        session.stop();
        VisionProfile p = new VisionProfile();
        session.start(p);
        long base = session.getStartedAtMs();
        VisionContextState state = new VisionContextState();
        long now = base + 65L * 60L * 1000L;
        VisionContextEngine.Proposal proposal = VisionContextEngine.nextExternalProposal(p, session, state, now, 14);
        require(proposal != null, "external context proposal created for long session");
        boolean visibleOutside = Math.abs(proposal.candidate.externalMagnification - proposal.baseline.externalMagnification) > 0.0001f ||
            Math.abs(proposal.candidate.externalDim - proposal.baseline.externalDim) > 0.0001f;
        require(visibleOutside, "external proposal changes an externally visible effect");
        session.stop();
    }

    private static void testContextDisabledBlocksProposal() {
        VisionSession session = VisionRuntime.session();
        session.stop();
        VisionProfile p = new VisionProfile();
        p.contextualAssistEnabled = false;
        session.start(p);
        long now = session.getStartedAtMs() + 2L * 60L * 60L * 1000L;
        VisionContextEngine.Proposal proposal = VisionContextEngine.nextProposal(p, session,
            new VisionContextState(), now, 23);
        require(proposal == null, "disabled contextual assistant creates no proposal");
        session.stop();
    }

    private static void testContextStressBounds() {
        VisionSession session = VisionRuntime.session();
        session.stop();
        VisionProfile p = new VisionProfile();
        session.start(p);
        long base = session.getStartedAtMs();
        VisionContextState state = new VisionContextState();
        for (int i = 0; i < 300; i++) {
            long now = base + (20L + i) * 60L * 1000L;
            float lux = (i % 4 == 0) ? 6f : ((i % 4 == 1) ? 25f : ((i % 4 == 2) ? 6500f : 450f));
            state.updateAmbientLux(lux, now);
            if (i % 3 == 0) session.noteUserCorrection(now - 1000L);
            VisionContextEngine.Proposal proposal = VisionContextEngine.nextProposal(p, session, state, now, i % 24);
            if (proposal != null) {
                VisionContextEngine.Response r = (i % 5 == 0) ? VisionContextEngine.Response.WORSE :
                    ((i % 7 == 0) ? VisionContextEngine.Response.SAME : VisionContextEngine.Response.BETTER);
                if (r == VisionContextEngine.Response.BETTER) p.adoptPresentationFrom(proposal.candidate);
                VisionContextEngine.respond(p, r);
                assertBounds(p);
            }
        }
        require(p.contextAccepted + p.contextRejected + p.contextNeutral > 0,
            "context stress generated learning events");
        session.stop();
    }

    private static void assertBounds(VisionProfile p) {
        require(p.fontScale >= 0.80f && p.fontScale <= 1.70f, "fontScale bounds");
        require(p.letterSpacingEm >= -0.03f && p.letterSpacingEm <= 0.18f, "letterSpacing bounds");
        require(p.lineHeight >= 1.10f && p.lineHeight <= 2.20f, "lineHeight bounds");
        require(p.contrast >= 0.70f && p.contrast <= 1.60f, "contrast bounds");
        require(p.brightness >= 0.65f && p.brightness <= 1.35f, "brightness bounds");
        require(p.externalMagnification >= 1.00f && p.externalMagnification <= 2.50f, "external magnification bounds");
        require(p.externalDim >= 0.00f && p.externalDim <= 0.60f, "external dim bounds");
        require(p.contextAccepted >= 0 && p.contextRejected >= 0 && p.contextNeutral >= 0, "context counters nonnegative");
        require(p.tuneAxis >= 0 && p.tuneAxis < VisionTuningEngine.AXIS_COUNT, "axis bounds");
        require(p.tunePrecision >= 0 && p.tunePrecision <= VisionTuningEngine.MAX_PRECISION, "precision bounds");
        for (int i = 0; i < VisionTuningEngine.AXIS_COUNT; i++) {
            require(p.preferredDirection[i] >= -1 && p.preferredDirection[i] <= 1, "direction memory bounds");
            require(p.axisBetter[i] >= 0 && p.axisWorse[i] >= 0 && p.axisSame[i] >= 0, "evidence nonnegative");
        }
    }

    private static boolean equalPresentation(VisionProfile a, VisionProfile b) {
        return Math.abs(a.fontScale - b.fontScale) < 0.0001f &&
            Math.abs(a.letterSpacingEm - b.letterSpacingEm) < 0.0001f &&
            Math.abs(a.lineHeight - b.lineHeight) < 0.0001f &&
            Math.abs(a.contrast - b.contrast) < 0.0001f &&
            Math.abs(a.brightness - b.brightness) < 0.0001f &&
            Math.abs(a.externalMagnification - b.externalMagnification) < 0.0001f &&
            Math.abs(a.externalDim - b.externalDim) < 0.0001f;
    }

    private static void testPremiumTrialPolicy() {
        long start = 1_000_000L;
        require(MonetizationPolicy.hasAccess(false, start, start), "trial grants access at start");
        require(MonetizationPolicy.hasAccess(false, start, start + MonetizationPolicy.TRIAL_MS - 1L), "trial grants access before expiry");
        require(!MonetizationPolicy.hasAccess(false, start, start + MonetizationPolicy.TRIAL_MS), "trial expires exactly at boundary");
        require(MonetizationPolicy.trialDaysRemaining(start, start) == 7, "trial reports seven days at start");
        require(MonetizationPolicy.trialDaysRemaining(start, start + 6L * MonetizationPolicy.DAY_MS + 1L) == 1, "trial rounds remaining day upward");
        require(!MonetizationPolicy.hasAccess(false, 0L, start), "no phantom trial without start");
    }

    private static void testPremiumAlwaysWins() {
        require(MonetizationPolicy.hasAccess(true, 0L, Long.MAX_VALUE), "premium entitlement bypasses trial expiry");
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new IllegalStateException(message);
    }
}
