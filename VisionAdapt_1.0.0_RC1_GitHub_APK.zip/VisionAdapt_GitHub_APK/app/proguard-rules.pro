# MVP: sem regras adicionais por enquanto.
