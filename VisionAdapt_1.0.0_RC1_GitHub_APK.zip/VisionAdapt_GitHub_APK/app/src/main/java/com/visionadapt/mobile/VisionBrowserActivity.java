package com.visionadapt.mobile;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Calendar;

public class VisionBrowserActivity extends Activity {
    private VisionProfileStore profileStore;
    private VisionProfile profile;
    private VisionSession session;
    private ProductStateStore productStore;
    private WebView webView;
    private Button toggleButton;
    private Button tuneButton;
    private Button undoButton;
    private Button restoreButton;
    private Button contextButton;
    private VisionContextMonitor contextMonitor;
    private Handler contextHandler;
    private boolean resumed;
    private final Runnable contextTicker = new Runnable() {
        @Override
        public void run() {
            refreshContextButton();
            if (contextHandler != null && resumed) contextHandler.postDelayed(this, 30000L);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        productStore = new ProductStateStore(this);
        profileStore = new VisionProfileStore(this);
        profile = profileStore.load();
        session = VisionRuntime.session();
        contextMonitor = new VisionContextMonitor(this, VisionRuntime.context());
        contextHandler = new Handler(Looper.getMainLooper());

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);
        Ui.applySystemBarInsets(root, this, 0, 0, 0, 0);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setPadding(Ui.dp(this, 6), Ui.dp(this, 6), Ui.dp(this, 6), Ui.dp(this, 4));

        Button back = Ui.button(this, "←");
        back.setContentDescription("Voltar");
        back.setOnClickListener(v -> {
            if (webView != null && webView.canGoBack()) webView.goBack();
            else finish();
        });
        bar.addView(back, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.18f));

        toggleButton = Ui.button(this, "");
        toggleButton.setOnClickListener(v -> {
            session.toggle(profile);
            updateContextMonitoring();
            VisionAccessibilityBridge.requestRefresh();
            syncSessionUi();
            refreshContextButton();
            applyVision();
        });
        bar.addView(toggleButton, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.41f));

        tuneButton = Ui.button(this, "Não está bom");
        tuneButton.setOnClickListener(v -> showQuickTune());
        bar.addView(tuneButton, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.41f));
        root.addView(bar);

        LinearLayout safetyBar = new LinearLayout(this);
        safetyBar.setOrientation(LinearLayout.HORIZONTAL);
        safetyBar.setPadding(Ui.dp(this, 6), 0, Ui.dp(this, 6), Ui.dp(this, 4));

        undoButton = Ui.button(this, "Desfazer");
        undoButton.setOnClickListener(v -> undoLastChange());
        safetyBar.addView(undoButton, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        restoreButton = Ui.button(this, "Início");
        restoreButton.setOnClickListener(v -> restoreSessionStart());
        safetyBar.addView(restoreButton, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        contextButton = Ui.button(this, "Contexto");
        contextButton.setOnClickListener(v -> showContextTune());
        safetyBar.addView(contextButton, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(safetyBar);

        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setBuiltInZoomControls(true);
        settings.setDisplayZoomControls(false);
        settings.setLoadWithOverviewMode(true);
        settings.setUseWideViewPort(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setGeolocationEnabled(false);
        settings.setMediaPlaybackRequiresUserGesture(true);
        settings.setSupportMultipleWindows(false);
        if (android.os.Build.VERSION.SDK_INT >= 26) settings.setSafeBrowsingEnabled(true);

        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String next = request == null || request.getUrl() == null ? "" : request.getUrl().toString();
                return !next.startsWith("https://");
            }

            @SuppressWarnings("deprecation")
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return url == null || !url.startsWith("https://");
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                applyVision();
            }
        });

        root.addView(webView, new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        syncSessionUi();

        String url = getIntent().getStringExtra("url");
        if (url == null || url.trim().isEmpty()) url = "https://www.wikipedia.org";
        url = url.trim();
        if (url.startsWith("http://")) url = "https://" + url.substring(7);
        if (!url.startsWith("https://")) url = "https://" + url.replaceFirst("^[a-zA-Z][a-zA-Z0-9+.-]*://", "");
        webView.loadUrl(url);
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        if (profileStore != null) {
            profile = profileStore.load();
            syncSessionUi();
            applyVision();
            updateContextMonitoring();
            refreshContextButton();
        }
    }

    @Override
    protected void onPause() {
        resumed = false;
        if (contextHandler != null) contextHandler.removeCallbacks(contextTicker);
        if (contextMonitor != null) contextMonitor.stop();
        super.onPause();
    }

    private void syncSessionUi() {
        if (toggleButton == null) return;
        boolean active = session.isActive();
        toggleButton.setText(active ? "Visão: ON" : "Visão: OFF");
        tuneButton.setEnabled(active);
        undoButton.setEnabled(active && session.canUndo());
        restoreButton.setEnabled(active && session.canRestoreSessionStart());
        if (contextButton != null) contextButton.setEnabled(active && profile != null && (profile.contextualAssistEnabled || !hasPremiumAccess()));
    }

    private void applyVision() {
        if (webView == null || profile == null) return;
        boolean active = session.isActive();
        webView.getSettings().setTextZoom(active ? Math.round(profile.fontScale * 100f) : 100);
        String script = active ? VisionCss.injectionScript(profile) : VisionCss.removalScript();
        webView.evaluateJavascript(script, null);
    }

    private void renderTemporary(VisionProfile temporary) {
        if (temporary == null) return;
        webView.getSettings().setTextZoom(Math.round(temporary.fontScale * 100f));
        webView.evaluateJavascript(VisionCss.injectionScript(temporary), null);
    }

    private void showQuickTune() {
        if (!session.isActive()) return;
        session.noteUserCorrection();
        refreshContextButton();

        final VisionTuningEngine.Proposal proposal = VisionTuningEngine.nextProposal(profile);
        final VisionProfile baseline = proposal.baseline;
        final VisionProfile candidate = proposal.candidate;
        final boolean candidateIsA = (System.nanoTime() & 1L) == 0L;
        final VisionProfile versionA = candidateIsA ? candidate : baseline;
        final VisionProfile versionB = candidateIsA ? baseline : candidate;
        final boolean[] seen = {true, false};

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(Ui.dp(this, 18), Ui.dp(this, 8), Ui.dp(this, 18), Ui.dp(this, 4));

        TextView hint = Ui.body(this,
            "A e B são cegas: nenhuma delas revela se é a configuração atual. Alterne as duas e escolha pela leitura mais fácil.", 15);
        panel.addView(hint, Ui.matchWrap(this, 4));

        LinearLayout switches = Ui.horizontal(this);
        Button showA = Ui.button(this, "Ver A");
        Button showB = Ui.button(this, "Ver B");
        switches.addView(showA, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        switches.addView(showB, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        panel.addView(switches, Ui.matchWrap(this, 10));

        TextView showing = Ui.body(this, "Mostrando A", 14);
        panel.addView(showing, Ui.matchWrap(this, 8));

        AlertDialog dialog = new AlertDialog.Builder(this)
            .setTitle("Qual ficou mais fácil de ler?")
            .setView(panel)
            .setNegativeButton("A melhor", null)
            .setNeutralButton("Sem diferença", null)
            .setPositiveButton("B melhor", null)
            .create();

        showA.setOnClickListener(v -> {
            seen[0] = true;
            renderTemporary(versionA);
            showing.setText("Mostrando A");
            updateDecisionEnabled(dialog, seen);
        });
        showB.setOnClickListener(v -> {
            seen[1] = true;
            renderTemporary(versionB);
            showing.setText("Mostrando B");
            updateDecisionEnabled(dialog, seen);
        });

        dialog.setOnShowListener(d -> {
            renderTemporary(versionA);
            updateDecisionEnabled(dialog, seen);

            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v -> {
                applyBlindChoice(proposal, candidateIsA, true);
                dialog.dismiss();
            });
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                VisionTuningEngine.respond(profile, proposal, VisionTuningEngine.Response.SAME);
                profileStore.save(profile);
                VisionAccessibilityBridge.requestRefresh();
                applyVision();
                syncSessionUi();
                dialog.dismiss();
            });
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                applyBlindChoice(proposal, candidateIsA, false);
                dialog.dismiss();
            });
        });

        dialog.setOnCancelListener(d -> applyVision());
        dialog.show();
    }

    private void applyBlindChoice(VisionTuningEngine.Proposal proposal, boolean candidateIsA, boolean choseA) {
        boolean choseCandidate = candidateIsA == choseA;
        if (choseCandidate) session.recordCheckpoint(profile);
        VisionTuningEngine.respond(profile, proposal,
            choseCandidate ? VisionTuningEngine.Response.BETTER : VisionTuningEngine.Response.WORSE);
        profileStore.save(profile);
        VisionAccessibilityBridge.requestRefresh();
        applyVision();
        syncSessionUi();
    }

    private int currentHour() {
        return Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
    }

    private void updateContextMonitoring() {
        if (contextHandler == null || contextMonitor == null || profile == null) return;
        contextHandler.removeCallbacks(contextTicker);
        boolean shouldRun = resumed && session.isActive() && profile.contextualAssistEnabled && hasPremiumAccess();
        boolean serviceSuppliesSensor = VisionAccessibilityStatus.isEnabled(this);
        if (shouldRun) {
            if (serviceSuppliesSensor) contextMonitor.stop(); else contextMonitor.start();
            contextHandler.post(contextTicker);
        } else {
            contextMonitor.stop();
        }
    }

    private void refreshContextButton() {
        if (contextButton == null || profile == null || session == null) return;
        VisionContextEngine.Proposal proposal = VisionContextEngine.nextProposal(profile, session,
            VisionRuntime.context(), System.currentTimeMillis(), currentHour());
        if (!hasPremiumAccess()) {
            contextButton.setEnabled(session.isActive());
            contextButton.setText("Premium");
            return;
        }
        boolean enabled = session.isActive() && profile.contextualAssistEnabled && proposal != null;
        contextButton.setEnabled(enabled);
        contextButton.setText(enabled ? "Contexto • ajustar" : "Contexto");
    }

    private void showContextTune() {
        if (!hasPremiumAccess()) {
            new AlertDialog.Builder(this)
                .setTitle("Recurso Premium")
                .setMessage("A assistência contextual faz parte do Premium. O ajuste A/B desta página continua gratuito.")
                .setNegativeButton("Agora não", null)
                .setPositiveButton("Ver Premium", (d, w) -> startActivity(new Intent(this, PremiumActivity.class)))
                .show();
            return;
        }
        if (!session.isActive() || !profile.contextualAssistEnabled) return;
        final VisionContextEngine.Proposal proposal = VisionContextEngine.nextProposal(profile, session,
            VisionRuntime.context(), System.currentTimeMillis(), currentHour());
        if (proposal == null) return;

        final VisionProfile baseline = proposal.baseline;
        final VisionProfile candidate = proposal.candidate;
        final boolean candidateIsA = (System.nanoTime() & 1L) == 0L;
        final VisionProfile versionA = candidateIsA ? candidate : baseline;
        final VisionProfile versionB = candidateIsA ? baseline : candidate;
        final boolean[] seen = {true, false};

        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(Ui.dp(this, 18), Ui.dp(this, 8), Ui.dp(this, 18), Ui.dp(this, 4));
        panel.addView(Ui.body(this,
            "Microajuste sugerido pelo contexto da sessão. Alterne A/B e escolha apenas pela leitura.", 15),
            Ui.matchWrap(this, 4));

        LinearLayout switches = Ui.horizontal(this);
        Button showA = Ui.button(this, "Ver A");
        Button showB = Ui.button(this, "Ver B");
        switches.addView(showA, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        switches.addView(showB, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        panel.addView(switches, Ui.matchWrap(this, 10));
        TextView showing = Ui.body(this, "Mostrando A", 14);
        panel.addView(showing, Ui.matchWrap(this, 8));

        AlertDialog dialog = new AlertDialog.Builder(this)
            .setTitle("O ajuste contextual ajudou?")
            .setView(panel)
            .setNegativeButton("A melhor", null)
            .setNeutralButton("Sem diferença", null)
            .setPositiveButton("B melhor", null)
            .create();

        showA.setOnClickListener(v -> {
            seen[0] = true;
            renderTemporary(versionA);
            showing.setText("Mostrando A");
            updateDecisionEnabled(dialog, seen);
        });
        showB.setOnClickListener(v -> {
            seen[1] = true;
            renderTemporary(versionB);
            showing.setText("Mostrando B");
            updateDecisionEnabled(dialog, seen);
        });

        dialog.setOnShowListener(d -> {
            renderTemporary(versionA);
            updateDecisionEnabled(dialog, seen);
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v -> {
                applyContextChoice(proposal, candidateIsA, true);
                dialog.dismiss();
            });
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                VisionContextEngine.respond(profile, VisionContextEngine.Response.SAME);
                profileStore.save(profile);
                applyVision();
                refreshContextButton();
                dialog.dismiss();
            });
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                applyContextChoice(proposal, candidateIsA, false);
                dialog.dismiss();
            });
        });
        dialog.setOnCancelListener(d -> applyVision());
        dialog.show();
    }

    private void applyContextChoice(VisionContextEngine.Proposal proposal,
                                    boolean candidateIsA, boolean choseA) {
        boolean choseCandidate = candidateIsA == choseA;
        if (choseCandidate) {
            session.recordCheckpoint(profile);
            profile.adoptPresentationFrom(proposal.candidate);
            VisionContextEngine.respond(profile, VisionContextEngine.Response.BETTER);
        } else {
            VisionContextEngine.respond(profile, VisionContextEngine.Response.WORSE);
        }
        profileStore.save(profile);
        VisionAccessibilityBridge.requestRefresh();
        applyVision();
        syncSessionUi();
        refreshContextButton();
    }

    private void updateDecisionEnabled(AlertDialog dialog, boolean[] seen) {
        if (dialog == null || !dialog.isShowing()) return;
        boolean enabled = seen[0] && seen[1];
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setEnabled(enabled);
        dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setEnabled(enabled);
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(enabled);
    }

    private void undoLastChange() {
        VisionProfile previous = session.popUndo();
        if (previous == null) return;
        profile = previous;
        profileStore.save(profile);
        VisionAccessibilityBridge.requestRefresh();
        applyVision();
        syncSessionUi();
    }

    private void restoreSessionStart() {
        VisionProfile start = session.getSessionStartProfile();
        if (start == null) return;
        session.recordCheckpoint(profile);
        profile.adoptPresentationFrom(start);
        VisionTuningEngine.onManualEdit(profile);
        profileStore.save(profile);
        VisionAccessibilityBridge.requestRefresh();
        applyVision();
        syncSessionUi();
    }

    private boolean hasPremiumAccess() {
        return productStore != null && productStore.hasPremiumAccess(System.currentTimeMillis());
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (contextHandler != null) contextHandler.removeCallbacks(contextTicker);
        if (contextMonitor != null) contextMonitor.stop();
        if (webView != null) {
            webView.stopLoading();
            webView.loadUrl("about:blank");
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
