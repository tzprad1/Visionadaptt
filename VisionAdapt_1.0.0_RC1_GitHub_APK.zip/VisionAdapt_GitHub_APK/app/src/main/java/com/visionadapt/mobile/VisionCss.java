package com.visionadapt.mobile;

import java.util.Locale;

/** Converts the visual profile into a reversible WebView presentation layer. */
public final class VisionCss {
    private VisionCss() {}

    public static String build(VisionProfile p) {
        return String.format(Locale.US,
            "html{filter:brightness(%.3f) contrast(%.3f) !important;" +
            "transition:filter 180ms ease !important;}" +
            "body{line-height:%.3f !important;}" +
            "p,li,span,a,button,input,textarea,label,h1,h2,h3,h4,h5,h6{" +
            "letter-spacing:%.3fem !important;line-height:%.3f !important;" +
            "transition:letter-spacing 180ms ease,line-height 180ms ease !important;}" +
            "img,video,canvas,svg{transition:filter 180ms ease !important;}",
            p.brightness, p.contrast,
            p.lineHeight, p.letterSpacingEm, p.lineHeight
        );
    }

    public static String injectionScript(VisionProfile p) {
        String css = build(p).replace("\\", "\\\\").replace("`", "\\`");
        return "(function(){" +
            "var id='visionadapt-style';" +
            "var s=document.getElementById(id);" +
            "if(!s){s=document.createElement('style');s.id=id;s.type='text/css';" +
            "(document.head||document.documentElement).appendChild(s);}" +
            "s.textContent=`" + css + "`;" +
            "})();";
    }

    public static String removalScript() {
        return "(function(){var e=document.getElementById('visionadapt-style');if(e)e.remove();})();";
    }
}
