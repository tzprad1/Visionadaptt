package com.visionadapt.mobile;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityService.MagnificationController;
import android.accessibilityservice.MagnificationConfig;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.Calendar;
import java.util.Locale;

/**
 * Optional system bridge for VisionAdapt.
 *
 * What it really does outside the app:
 * - exposes a persistent accessibility overlay controlled by the user;
 * - controls Android full-screen magnification through the official accessibility API;
 * - can place a non-touchable neutral dim layer over the display.
 *
 * It does NOT claim to rewrite arbitrary app pixels, fonts or layout. Those richer transforms
 * remain available in VisionAdapt's own renderer/browser until a future rendering pipeline exists.
 */
public class VisionAccessibilityService extends AccessibilityService {
    private static final float MAG_STEP = 0.10f;
    private static final float DIM_STEP = 0.05f;

    private WindowManager windowManager;
    private VisionProfileStore profileStore;
    private VisionProfile profile;
    private VisionSession session;
    private ProductStateStore productStore;

    private View capsule;
    private WindowManager.LayoutParams capsuleParams;
    private LinearLayout panel;
    private ScrollView panelHost;
    private WindowManager.LayoutParams panelParams;
    private View dimLayer;
    private WindowManager.LayoutParams dimParams;
    private TextView capsuleLabel;
    private TextView panelStatus;
    private Button panelToggle;
    private Button undoButton;
    private Button restoreButton;
    private TextView contextStatus;
    private Button contextTryButton;
    private Button contextGoodButton;
    private Button contextBadButton;
    private VisionContextMonitor contextMonitor;
    private Handler contextHandler;
    private VisionProfile pendingContextBaseline;
    private final Runnable contextTicker = new Runnable() {
        @Override
        public void run() {
            syncOverlayText();
            if (contextHandler != null) contextHandler.postDelayed(this, 30000L);
        }
    };
    private boolean panelVisible;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        productStore = new ProductStateStore(this);
        profileStore = new VisionProfileStore(this);
        profile = profileStore.load();
        session = VisionRuntime.session();
        contextMonitor = new VisionContextMonitor(this, VisionRuntime.context());
        contextHandler = new Handler(Looper.getMainLooper());
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        VisionAccessibilityBridge.attach(this);
        refreshFromSharedState();
        updateContextMonitoring();
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // Deliberately no window-content inspection. We only look at the
        // event package name so our floating control does not duplicate the in-app controls.
        CharSequence eventPackage = event == null ? null : event.getPackageName();
        boolean ownApp = eventPackage != null && getPackageName().contentEquals(eventPackage);
        if (!hasPremiumAccess()) {
            resetMagnification(false);
            setDimAlpha(0f);
            if (panelVisible) hidePanel();
            if (capsule != null) capsule.setVisibility(View.GONE);
            return;
        }
        if (capsule != null) capsule.setVisibility(ownApp ? View.GONE : View.VISIBLE);
        if (ownApp && panelVisible) hidePanel();
        syncOverlayText();
    }

    @Override
    public void onInterrupt() {
        // No continuous spoken/haptic feedback to interrupt.
    }

    public void refreshFromSharedState() {
        if (profileStore == null) return;
        profile = profileStore.load();
        if (session == null) session = VisionRuntime.session();
        if (!hasPremiumAccess()) {
            if (contextHandler != null) contextHandler.removeCallbacks(contextTicker);
            if (contextMonitor != null) contextMonitor.stop();
            resetMagnification(false);
            setDimAlpha(0f);
            if (panelHost != null && panelHost.getParent() != null) windowManager.removeView(panelHost);
            panelVisible = false;
            if (capsule != null) capsule.setVisibility(View.GONE);
            return;
        }
        createCapsuleIfNeeded();
        if (capsule != null) capsule.setVisibility(View.VISIBLE);
        applySystemEffects(false);
        updateContextMonitoring();
        syncOverlayText();
    }

    private void createCapsuleIfNeeded() {
        if (windowManager == null || capsule != null) return;

        Button button = Ui.button(this, "👁 VISÃO");
        button.setTextSize(14f);
        button.setTextColor(Color.WHITE);
        button.setPadding(Ui.dp(this, 14), 0, Ui.dp(this, 14), 0);
        button.setBackground(roundRect(Color.rgb(24, 24, 24), 24));
        button.setContentDescription("Abrir controles do VisionAdapt");
        capsule = button;
        capsuleLabel = button;

        capsuleParams = new WindowManager.LayoutParams(
            Ui.dp(this, 116), Ui.dp(this, 54),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        capsuleParams.gravity = Gravity.TOP | Gravity.START;
        int width = getResources().getDisplayMetrics().widthPixels;
        capsuleParams.x = Math.max(Ui.dp(this, 8), width - Ui.dp(this, 132));
        capsuleParams.y = Ui.dp(this, 180);

        installDragAndTap(button);
        windowManager.addView(capsule, capsuleParams);
    }

    private void installDragAndTap(View view) {
        view.setOnTouchListener(new View.OnTouchListener() {
            float downRawX;
            float downRawY;
            int downX;
            int downY;
            boolean moved;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (capsuleParams == null || windowManager == null) return false;
                switch (event.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX = event.getRawX();
                        downRawY = event.getRawY();
                        downX = capsuleParams.x;
                        downY = capsuleParams.y;
                        moved = false;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        float dx = event.getRawX() - downRawX;
                        float dy = event.getRawY() - downRawY;
                        if (Math.abs(dx) > Ui.dp(VisionAccessibilityService.this, 5) ||
                            Math.abs(dy) > Ui.dp(VisionAccessibilityService.this, 5)) moved = true;
                        int maxX = Math.max(0, getResources().getDisplayMetrics().widthPixels - Math.max(capsule.getWidth(), Ui.dp(VisionAccessibilityService.this, 116)));
                        int maxY = Math.max(0, getResources().getDisplayMetrics().heightPixels - Math.max(capsule.getHeight(), Ui.dp(VisionAccessibilityService.this, 54)));
                        capsuleParams.x = Math.max(0, Math.min(maxX, downX + Math.round(dx)));
                        capsuleParams.y = Math.max(0, Math.min(maxY, downY + Math.round(dy)));
                        windowManager.updateViewLayout(capsule, capsuleParams);
                        return true;
                    case MotionEvent.ACTION_UP:
                        if (!moved) togglePanel();
                        return true;
                    case MotionEvent.ACTION_CANCEL:
                        return true;
                    default:
                        return false;
                }
            }
        });
    }

    private void togglePanel() {
        if (panelVisible) hidePanel(); else showPanel();
    }

    private void showPanel() {
        if (windowManager == null) return;
        if (panel == null) buildPanel();
        if (panelHost != null && panelHost.getParent() == null) {
            windowManager.addView(panelHost, panelParams);
        }
        panelVisible = true;
        syncOverlayText();
    }

    private void hidePanel() {
        if (windowManager != null && panelHost != null && panelHost.getParent() != null) {
            windowManager.removeView(panelHost);
        }
        panelVisible = false;
    }

    private void buildPanel() {
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 14), Ui.dp(this, 14));
        panel.setBackground(roundRect(Color.WHITE, 20));
        panel.setElevation(Ui.dp(this, 8));

        TextView title = Ui.title(this, "VisionAdapt", 19);
        panel.addView(title, Ui.matchWrap(this, 0));

        panelStatus = Ui.body(this, "", 13);
        panel.addView(panelStatus, Ui.matchWrap(this, 6));

        panelToggle = Ui.button(this, "Iniciar visão");
        panelToggle.setOnClickListener(v -> toggleSessionFromOverlay());
        panel.addView(panelToggle, Ui.matchWrap(this, 8));

        panel.addView(Ui.body(this, "Ampliação da tela", 14), Ui.matchWrap(this, 12));
        LinearLayout magRow = Ui.horizontal(this);
        Button magMinus = Ui.button(this, "−");
        Button magPlus = Ui.button(this, "+");
        magMinus.setContentDescription("Diminuir ampliação");
        magPlus.setContentDescription("Aumentar ampliação");
        magMinus.setOnClickListener(v -> adjustMagnification(-MAG_STEP));
        magPlus.setOnClickListener(v -> adjustMagnification(MAG_STEP));
        magRow.addView(magMinus, new LinearLayout.LayoutParams(0, Ui.dp(this, 50), 1f));
        magRow.addView(magPlus, new LinearLayout.LayoutParams(0, Ui.dp(this, 50), 1f));
        panel.addView(magRow, Ui.matchWrap(this, 4));

        panel.addView(Ui.body(this, "Redução luminosa", 14), Ui.matchWrap(this, 12));
        LinearLayout dimRow = Ui.horizontal(this);
        Button dimMinus = Ui.button(this, "−");
        Button dimPlus = Ui.button(this, "+");
        dimMinus.setContentDescription("Diminuir redução luminosa");
        dimPlus.setContentDescription("Aumentar redução luminosa");
        dimMinus.setOnClickListener(v -> adjustDim(-DIM_STEP));
        dimPlus.setOnClickListener(v -> adjustDim(DIM_STEP));
        dimRow.addView(dimMinus, new LinearLayout.LayoutParams(0, Ui.dp(this, 50), 1f));
        dimRow.addView(dimPlus, new LinearLayout.LayoutParams(0, Ui.dp(this, 50), 1f));
        panel.addView(dimRow, Ui.matchWrap(this, 4));

        contextStatus = Ui.body(this, "", 13);
        panel.addView(contextStatus, Ui.matchWrap(this, 12));
        contextTryButton = Ui.button(this, "Testar microajuste contextual");
        contextTryButton.setOnClickListener(v -> applyContextTrial());
        panel.addView(contextTryButton, Ui.matchWrap(this, 5));

        LinearLayout contextFeedback = Ui.horizontal(this);
        contextGoodButton = Ui.button(this, "Ajudou");
        contextBadButton = Ui.button(this, "Não ajudou");
        contextGoodButton.setOnClickListener(v -> confirmContextTrial(true));
        contextBadButton.setOnClickListener(v -> confirmContextTrial(false));
        contextFeedback.addView(contextGoodButton, new LinearLayout.LayoutParams(0, Ui.dp(this, 48), 1f));
        contextFeedback.addView(contextBadButton, new LinearLayout.LayoutParams(0, Ui.dp(this, 48), 1f));
        panel.addView(contextFeedback, Ui.matchWrap(this, 4));

        LinearLayout safety = Ui.horizontal(this);
        undoButton = Ui.button(this, "Desfazer");
        restoreButton = Ui.button(this, "Início");
        undoButton.setOnClickListener(v -> undoLast());
        restoreButton.setOnClickListener(v -> restoreSessionStart());
        safety.addView(undoButton, new LinearLayout.LayoutParams(0, Ui.dp(this, 52), 1f));
        safety.addView(restoreButton, new LinearLayout.LayoutParams(0, Ui.dp(this, 52), 1f));
        panel.addView(safety, Ui.matchWrap(this, 10));

        Button resetExternal = Ui.button(this, "Repor só a tela externa");
        resetExternal.setOnClickListener(v -> resetExternalEffects());
        panel.addView(resetExternal, Ui.matchWrap(this, 6));

        Button openApp = Ui.button(this, "Abrir VisionAdapt");
        openApp.setOnClickListener(v -> openMainApp());
        panel.addView(openApp, Ui.matchWrap(this, 6));

        Button close = Ui.button(this, "Fechar controles");
        close.setOnClickListener(v -> hidePanel());
        panel.addView(close, Ui.matchWrap(this, 6));

        panelHost = new ScrollView(this);
        panelHost.setFillViewport(false);
        panelHost.addView(panel, new ScrollView.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        int availableHeight = Math.max(Ui.dp(this, 320),
            getResources().getDisplayMetrics().heightPixels - Ui.dp(this, 120));
        panelParams = new WindowManager.LayoutParams(
            Ui.dp(this, 286), Math.min(Ui.dp(this, 620), availableHeight),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.END;
        panelParams.x = Ui.dp(this, 10);
        panelParams.y = Ui.dp(this, 88);
    }

    private void toggleSessionFromOverlay() {
        reloadProfile();
        if (session.isActive()) {
            session.stop();
            pendingContextBaseline = null;
        } else {
            session.start(profile);
        }
        updateContextMonitoring();
        applySystemEffects(true);
        syncOverlayText();
    }

    private void adjustMagnification(float delta) {
        if (!ensureActive()) return;
        reloadProfile();
        VisionProfile before = profile.copy();
        profile.externalMagnification += delta;
        profile.normalize();
        if (Math.abs(before.externalMagnification - profile.externalMagnification) < 0.0001f) return;
        session.recordCheckpoint(before);
        session.noteUserCorrection();
        pendingContextBaseline = null;
        profileStore.save(profile);
        applySystemEffects(true);
        syncOverlayText();
    }

    private void adjustDim(float delta) {
        if (!ensureActive()) return;
        reloadProfile();
        VisionProfile before = profile.copy();
        profile.externalDim += delta;
        profile.normalize();
        if (Math.abs(before.externalDim - profile.externalDim) < 0.0001f) return;
        session.recordCheckpoint(before);
        session.noteUserCorrection();
        pendingContextBaseline = null;
        profileStore.save(profile);
        applySystemEffects(true);
        syncOverlayText();
    }

    private void resetExternalEffects() {
        if (!ensureActive()) return;
        reloadProfile();
        if (Math.abs(profile.externalMagnification - 1f) < 0.0001f &&
            Math.abs(profile.externalDim) < 0.0001f) return;
        session.recordCheckpoint(profile);
        session.noteUserCorrection();
        pendingContextBaseline = null;
        profile.externalMagnification = 1f;
        profile.externalDim = 0f;
        profile.normalize();
        profileStore.save(profile);
        applySystemEffects(true);
        syncOverlayText();
    }

    private int currentHour() {
        return Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
    }

    private void updateContextMonitoring() {
        if (contextHandler == null || contextMonitor == null || profile == null || session == null) return;
        contextHandler.removeCallbacks(contextTicker);
        boolean shouldRun = hasPremiumAccess() && session.isActive() && profile.contextualAssistEnabled;
        if (shouldRun) {
            contextMonitor.start();
            contextHandler.post(contextTicker);
        } else {
            contextMonitor.stop();
        }
    }

    private VisionContextEngine.Proposal contextProposal() {
        if (!hasPremiumAccess() || profile == null || session == null) return null;
        return VisionContextEngine.nextExternalProposal(profile, session, VisionRuntime.context(),
            System.currentTimeMillis(), currentHour());
    }

    private void applyContextTrial() {
        if (!ensureActive() || pendingContextBaseline != null) return;
        reloadProfile();
        VisionContextEngine.Proposal proposal = contextProposal();
        if (proposal == null) {
            syncOverlayText();
            return;
        }
        pendingContextBaseline = profile.copy();
        session.recordCheckpoint(profile);
        profile.adoptPresentationFrom(proposal.candidate);
        profileStore.save(profile);
        applySystemEffects(true);
        syncOverlayText();
    }

    private void confirmContextTrial(boolean helped) {
        if (pendingContextBaseline == null) return;
        if (helped) {
            VisionContextEngine.respond(profile, VisionContextEngine.Response.BETTER);
            profileStore.save(profile);
        } else {
            // Remove the trial checkpoint and restore exactly what was visible before the trial.
            VisionProfile previous = session.popUndo();
            profile = previous == null ? pendingContextBaseline.copy() : previous;
            VisionContextEngine.respond(profile, VisionContextEngine.Response.WORSE);
            profileStore.save(profile);
            applySystemEffects(true);
        }
        pendingContextBaseline = null;
        syncOverlayText();
    }

    private void undoLast() {
        if (!session.isActive()) return;
        pendingContextBaseline = null;
        VisionProfile previous = session.popUndo();
        if (previous == null) return;
        profile = previous;
        profileStore.save(profile);
        applySystemEffects(true);
        syncOverlayText();
    }

    private void restoreSessionStart() {
        if (!session.isActive()) return;
        pendingContextBaseline = null;
        VisionProfile start = session.getSessionStartProfile();
        if (start == null) return;
        reloadProfile();
        session.recordCheckpoint(profile);
        profile.adoptPresentationFrom(start);
        VisionTuningEngine.onManualEdit(profile);
        profileStore.save(profile);
        applySystemEffects(true);
        syncOverlayText();
    }

    private boolean ensureActive() {
        if (session == null) session = VisionRuntime.session();
        return session.isActive();
    }

    private void reloadProfile() {
        if (profileStore == null) profileStore = new VisionProfileStore(this);
        profile = profileStore.load();
    }

    private void applySystemEffects(boolean animate) {
        if (profile == null) reloadProfile();
        if (session == null) session = VisionRuntime.session();

        if (!session.isActive()) {
            resetMagnification(animate);
            setDimAlpha(0f);
            return;
        }

        setMagnification(profile.externalMagnification, animate);
        setDimAlpha(profile.externalDim);
    }

    @SuppressWarnings("deprecation")
    private boolean setMagnification(float scale, boolean animate) {
        try {
            MagnificationController controller = getMagnificationController();
            float safe = VisionProfile.clamp(scale, 1f, 2.50f);
            if (safe <= 1.001f) return resetMagnification(animate);

            if (Build.VERSION.SDK_INT >= 33) {
                MagnificationConfig.Builder builder = new MagnificationConfig.Builder()
                    .setMode(MagnificationConfig.MAGNIFICATION_MODE_FULLSCREEN)
                    .setScale(safe);
                if (Build.VERSION.SDK_INT >= 34) builder.setActivated(true);
                return controller.setMagnificationConfig(builder.build(), animate);
            }
            return controller.setScale(safe, animate);
        } catch (Throwable ignored) {
            return false;
        }
    }

    @SuppressWarnings("deprecation")
    private boolean resetMagnification(boolean animate) {
        try {
            MagnificationController controller = getMagnificationController();
            if (Build.VERSION.SDK_INT >= 33) {
                return controller.resetCurrentMagnification(animate);
            }
            return controller.reset(animate);
        } catch (Throwable ignored) {
            return false;
        }
    }

    private void setDimAlpha(float alpha) {
        float safe = VisionProfile.clamp(alpha, 0f, 0.60f);
        if (windowManager == null) return;

        if (safe <= 0.001f) {
            if (dimLayer != null && dimLayer.getParent() != null) {
                windowManager.removeView(dimLayer);
            }
            return;
        }

        if (dimLayer == null) {
            dimLayer = new View(this);
            dimLayer.setBackgroundColor(Color.BLACK);
            dimParams = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
            dimParams.gravity = Gravity.TOP | Gravity.START;
        }
        dimLayer.setAlpha(safe);
        if (dimLayer.getParent() == null) {
            // Add first so the control capsule/panel remains visually above it.
            windowManager.addView(dimLayer, dimParams);
            if (capsule != null && capsule.getParent() != null) {
                windowManager.removeView(capsule);
                windowManager.addView(capsule, capsuleParams);
            }
            if (panelVisible && panelHost != null && panelHost.getParent() != null) {
                windowManager.removeView(panelHost);
                windowManager.addView(panelHost, panelParams);
            }
        }
    }

    private void syncOverlayText() {
        if (!hasPremiumAccess()) {
            if (capsule != null) capsule.setVisibility(View.GONE);
            return;
        }
        if (session == null) session = VisionRuntime.session();
        if (profile == null && profileStore != null) profile = profileStore.load();
        boolean active = session.isActive();
        if (capsuleLabel != null) capsuleLabel.setText(active ? "👁 ON" : "👁 VISÃO");
        if (panelToggle != null) panelToggle.setText(active ? "Encerrar sessão" : "Iniciar visão");
        if (panelStatus != null && profile != null) {
            panelStatus.setText(String.format(Locale.US,
                "%s • ampliação %.2fx • redução luminosa %.0f%%\n" +
                "Fora do VisionAdapt, estes são os efeitos globais disponíveis atualmente.",
                active ? "Visão ativa" : "Visão desligada",
                profile.externalMagnification, profile.externalDim * 100f));
        }
        if (contextStatus != null && profile != null) {
            VisionContextEngine.Assessment a = VisionContextEngine.assess(profile, session,
                VisionRuntime.context(), System.currentTimeMillis(), currentHour());
            String level = a.level == VisionContextEngine.LoadLevel.ELEVATED ? "elevada" :
                (a.level == VisionContextEngine.LoadLevel.MODERATE ? "moderada" : "baixa");
            String lux = a.hasAmbientLux ? String.format(Locale.US, "%.0f lux", a.ambientLux) : "luz sem leitura";
            contextStatus.setText(String.format(Locale.US,
                "Contexto: carga %s • %d min • %s • %d correções recentes",
                level, a.elapsedMs / 60000L, lux, a.recentCorrections));
        }
        VisionContextEngine.Proposal cp = contextProposal();
        if (contextTryButton != null) {
            contextTryButton.setEnabled(active && profile != null && profile.contextualAssistEnabled &&
                pendingContextBaseline == null && cp != null);
            contextTryButton.setText(cp == null ? "Sem microajuste necessário agora" : "Testar microajuste contextual");
        }
        if (contextGoodButton != null) contextGoodButton.setEnabled(pendingContextBaseline != null);
        if (contextBadButton != null) contextBadButton.setEnabled(pendingContextBaseline != null);
        if (undoButton != null) undoButton.setEnabled(active && session.canUndo());
        if (restoreButton != null) restoreButton.setEnabled(active && session.canRestoreSessionStart());
    }

    private boolean hasPremiumAccess() {
        return productStore != null && productStore.hasPremiumAccess(System.currentTimeMillis());
    }

    private void openMainApp() {
        Intent intent = new Intent(this, MainActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(intent);
        hidePanel();
    }

    private GradientDrawable roundRect(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(Ui.dp(this, radiusDp));
        return d;
    }

    private void removeOverlays() {
        if (windowManager == null) return;
        if (panelHost != null && panelHost.getParent() != null) windowManager.removeView(panelHost);
        if (capsule != null && capsule.getParent() != null) windowManager.removeView(capsule);
        if (dimLayer != null && dimLayer.getParent() != null) windowManager.removeView(dimLayer);
        panelVisible = false;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        if (contextHandler != null) contextHandler.removeCallbacks(contextTicker);
        if (contextMonitor != null) contextMonitor.stop();
        resetMagnification(false);
        setDimAlpha(0f);
        removeOverlays();
        VisionAccessibilityBridge.detach(this);
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        if (contextHandler != null) contextHandler.removeCallbacks(contextTicker);
        if (contextMonitor != null) contextMonitor.stop();
        resetMagnification(false);
        setDimAlpha(0f);
        removeOverlays();
        VisionAccessibilityBridge.detach(this);
        super.onDestroy();
    }
}
