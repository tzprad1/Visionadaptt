package com.visionadapt.mobile;

import java.util.ArrayDeque;
import java.util.Deque;

/**
 * Process-scoped session state. It is intentionally NOT persisted to disk:
 * after a cold app start, VisionAdapt always begins with visual adaptation off.
 *
 * Reversible checkpoints make experimentation safe.
 */
public final class VisionSession {
    private static final int MAX_UNDO = 12;

    private boolean active;
    private long startedAtMs;
    private VisionProfile sessionStartProfile;
    private final Deque<VisionProfile> undoStack = new ArrayDeque<>();
    private final Deque<Long> correctionTimes = new ArrayDeque<>();

    VisionSession() {
        active = false;
        startedAtMs = 0L;
    }

    public boolean isActive() {
        return active;
    }

    public long getStartedAtMs() {
        return startedAtMs;
    }

    public long getElapsedMs() {
        return getElapsedMs(System.currentTimeMillis());
    }

    public long getElapsedMs(long nowMs) {
        if (!active || startedAtMs == 0L) return 0L;
        return Math.max(0L, nowMs - startedAtMs);
    }

    public void start() {
        start(null);
    }

    public void start(VisionProfile current) {
        if (active) return;
        active = true;
        startedAtMs = System.currentTimeMillis();
        sessionStartProfile = current == null ? null : current.copy();
        undoStack.clear();
        correctionTimes.clear();
    }

    public void stop() {
        active = false;
        startedAtMs = 0L;
        sessionStartProfile = null;
        undoStack.clear();
        correctionTimes.clear();
    }

    public void toggle() {
        if (active) stop(); else start();
    }

    public void toggle(VisionProfile current) {
        if (active) stop(); else start(current);
    }

    public void recordCheckpoint(VisionProfile profile) {
        if (!active || profile == null) return;
        if (undoStack.size() >= MAX_UNDO) undoStack.removeFirst();
        undoStack.addLast(profile.copy());
    }

    public boolean canUndo() {
        return active && !undoStack.isEmpty();
    }

    public VisionProfile popUndo() {
        if (!canUndo()) return null;
        return undoStack.removeLast().copy();
    }

    public boolean canRestoreSessionStart() {
        return active && sessionStartProfile != null;
    }

    public VisionProfile getSessionStartProfile() {
        return sessionStartProfile == null ? null : sessionStartProfile.copy();
    }

    public int undoDepth() {
        return undoStack.size();
    }

    /** Records that the user actively asked for or made a visual correction. */
    public void noteUserCorrection() {
        noteUserCorrection(System.currentTimeMillis());
    }

    public void noteUserCorrection(long nowMs) {
        if (!active) return;
        long safe = Math.max(0L, nowMs);
        correctionTimes.addLast(safe);
        pruneCorrections(safe, 60L * 60L * 1000L);
        while (correctionTimes.size() > 60) correctionTimes.removeFirst();
    }

    public int recentCorrectionCount(long nowMs, long windowMs) {
        if (!active) return 0;
        pruneCorrections(nowMs, Math.max(0L, windowMs));
        return correctionTimes.size();
    }

    private void pruneCorrections(long nowMs, long windowMs) {
        long floor = Math.max(0L, nowMs - windowMs);
        while (!correctionTimes.isEmpty() && correctionTimes.peekFirst() < floor) {
            correctionTimes.removeFirst();
        }
    }
}
