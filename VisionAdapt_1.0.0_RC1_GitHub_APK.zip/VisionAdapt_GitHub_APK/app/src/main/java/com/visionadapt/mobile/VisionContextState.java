package com.visionadapt.mobile;

/**
 * Process-scoped, non-medical context signals used by the adaptive assistant.
 * No screen contents are stored here. Ambient light is the only physical sensor signal used by this version.
 */
public final class VisionContextState {
    private float ambientLux = -1f;
    private long ambientLuxAtMs = 0L;

    public synchronized void updateAmbientLux(float lux, long nowMs) {
        if (Float.isNaN(lux) || Float.isInfinite(lux) || lux < 0f) return;
        ambientLux = lux;
        ambientLuxAtMs = Math.max(0L, nowMs);
    }

    public synchronized boolean hasFreshAmbientLux(long nowMs, long maxAgeMs) {
        if (ambientLuxAtMs <= 0L || ambientLux < 0f) return false;
        return Math.max(0L, nowMs - ambientLuxAtMs) <= Math.max(0L, maxAgeMs);
    }

    public synchronized float getAmbientLux() {
        return ambientLux;
    }

    public synchronized long getAmbientLuxAtMs() {
        return ambientLuxAtMs;
    }

    public synchronized void reset() {
        ambientLux = -1f;
        ambientLuxAtMs = 0L;
    }
}
