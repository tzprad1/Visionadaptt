package com.visionadapt.mobile;

import android.content.Context;
import android.content.SharedPreferences;

/** Single persistence boundary for the visual profile and tuning memory. */
public final class VisionProfileStore {
    private static final String PREFS = "vision_profile";
    private final SharedPreferences preferences;

    public VisionProfileStore(Context context) {
        preferences = context.getApplicationContext()
            .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public VisionProfile load() {
        VisionProfile v = new VisionProfile();
        v.fontScale = preferences.getFloat("fontScale", 1.00f);
        v.letterSpacingEm = preferences.getFloat("letterSpacingEm", 0.00f);
        v.lineHeight = preferences.getFloat("lineHeight", 1.45f);
        v.contrast = preferences.getFloat("contrast", 1.00f);
        v.brightness = preferences.getFloat("brightness", 1.00f);

        int schema = preferences.getInt("schemaVersion", 1);
        if (schema >= 4) {
            v.externalMagnification = preferences.getFloat("externalMagnification", 1.00f);
            v.externalDim = preferences.getFloat("externalDim", 0.00f);
        }

        if (schema >= 5) {
            v.contextualAssistEnabled = preferences.getBoolean("contextualAssistEnabled", true);
            v.contextAccepted = preferences.getInt("contextAccepted", 0);
            v.contextRejected = preferences.getInt("contextRejected", 0);
            v.contextNeutral = preferences.getInt("contextNeutral", 0);
        }

        if (schema >= 2) {
            v.tuneAxis = preferences.getInt("tuneAxis", 0);
            v.tuneDirection = preferences.getInt("tuneDirection", 1);
            v.tunePrecision = preferences.getInt("tunePrecision", 0);
            v.tuneAttemptsOnAxis = preferences.getInt("tuneAttemptsOnAxis", 0);
            v.rejectedAdjustments = preferences.getInt("rejectedAdjustments", 0);
            v.neutralAdjustments = preferences.getInt("neutralAdjustments", 0);
        } else {
            int oldTuneIndex = preferences.getInt("tuneIndex", 0);
            v.tuneAxis = Math.abs(oldTuneIndex) % VisionTuningEngine.AXIS_COUNT;
        }

        if (schema >= 3) {
            for (int i = 0; i < VisionTuningEngine.AXIS_COUNT; i++) {
                v.axisBetter[i] = preferences.getInt("axisBetter_" + i, 0);
                v.axisWorse[i] = preferences.getInt("axisWorse_" + i, 0);
                v.axisSame[i] = preferences.getInt("axisSame_" + i, 0);
                v.preferredDirection[i] = preferences.getInt("preferredDirection_" + i, 0);
            }
        }

        v.acceptedAdjustments = preferences.getInt("acceptedAdjustments", 0);
        v.normalize();
        return v;
    }

    public void save(VisionProfile v) {
        v.normalize();
        SharedPreferences.Editor editor = preferences.edit()
            .putInt("schemaVersion", VisionProfile.SCHEMA_VERSION)
            .putFloat("fontScale", v.fontScale)
            .putFloat("letterSpacingEm", v.letterSpacingEm)
            .putFloat("lineHeight", v.lineHeight)
            .putFloat("contrast", v.contrast)
            .putFloat("brightness", v.brightness)
            .putFloat("externalMagnification", v.externalMagnification)
            .putFloat("externalDim", v.externalDim)
            .putBoolean("contextualAssistEnabled", v.contextualAssistEnabled)
            .putInt("contextAccepted", v.contextAccepted)
            .putInt("contextRejected", v.contextRejected)
            .putInt("contextNeutral", v.contextNeutral)
            .putInt("tuneAxis", v.tuneAxis)
            .putInt("tuneDirection", v.tuneDirection)
            .putInt("tunePrecision", v.tunePrecision)
            .putInt("tuneAttemptsOnAxis", v.tuneAttemptsOnAxis)
            .putInt("acceptedAdjustments", v.acceptedAdjustments)
            .putInt("rejectedAdjustments", v.rejectedAdjustments)
            .putInt("neutralAdjustments", v.neutralAdjustments)
            .putLong("updatedAtMs", System.currentTimeMillis());

        for (int i = 0; i < VisionTuningEngine.AXIS_COUNT; i++) {
            editor.putInt("axisBetter_" + i, v.axisBetter[i]);
            editor.putInt("axisWorse_" + i, v.axisWorse[i]);
            editor.putInt("axisSame_" + i, v.axisSame[i]);
            editor.putInt("preferredDirection_" + i, v.preferredDirection[i]);
        }
        editor.apply();
    }
}
