package com.visionadapt.mobile;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Insets;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class Ui {
    private Ui() {}


    /** Keeps programmatic layouts clear of status/navigation bars on Android 15/16 edge-to-edge. */
    public static void applySystemBarInsets(View view, Context c, int leftDp, int topDp, int rightDp, int bottomDp) {
        if (view == null || c == null) return;
        final int baseLeft = dp(c, leftDp);
        final int baseTop = dp(c, topDp);
        final int baseRight = dp(c, rightDp);
        final int baseBottom = dp(c, bottomDp);
        view.setPadding(baseLeft, baseTop, baseRight, baseBottom);
        view.setOnApplyWindowInsetsListener((v, insets) -> {
            int left; int top; int right; int bottom;
            if (Build.VERSION.SDK_INT >= 30) {
                Insets bars = insets.getInsets(WindowInsets.Type.systemBars() | WindowInsets.Type.displayCutout());
                left = bars.left; top = bars.top; right = bars.right; bottom = bars.bottom;
            } else {
                left = insets.getSystemWindowInsetLeft();
                top = insets.getSystemWindowInsetTop();
                right = insets.getSystemWindowInsetRight();
                bottom = insets.getSystemWindowInsetBottom();
            }
            v.setPadding(baseLeft + left, baseTop + top, baseRight + right, baseBottom + bottom);
            return insets;
        });
        view.requestApplyInsets();
    }

    public static int dp(Context c, int value) {
        return Math.round(value * c.getResources().getDisplayMetrics().density);
    }

    public static TextView title(Context c, String text, float sp) {
        TextView t = new TextView(c);
        t.setText(text);
        t.setTextColor(Color.rgb(20,20,20));
        t.setTextSize(sp);
        t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    public static TextView body(Context c, String text, float sp) {
        TextView t = new TextView(c);
        t.setText(text);
        t.setTextColor(Color.rgb(62,62,62));
        t.setTextSize(sp);
        t.setLineSpacing(0, 1.28f);
        return t;
    }

    public static Button button(Context c, String text) {
        Button b = new Button(c);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(16);
        b.setMinHeight(dp(c, 52));
        return b;
    }

    public static Button primaryButton(Context c, String text) {
        Button b = button(c, text);
        b.setTextColor(Color.WHITE);
        b.setBackground(rounded(c, Color.rgb(22,22,22), 14));
        b.setPadding(dp(c, 14), dp(c, 10), dp(c, 14), dp(c, 10));
        return b;
    }

    public static Button secondaryButton(Context c, String text) {
        Button b = button(c, text);
        b.setTextColor(Color.rgb(28,28,28));
        GradientDrawable g = rounded(c, Color.WHITE, 14);
        g.setStroke(dp(c, 1), Color.rgb(215,215,210));
        b.setBackground(g);
        b.setPadding(dp(c, 14), dp(c, 10), dp(c, 14), dp(c, 10));
        return b;
    }

    public static LinearLayout card(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackground(rounded(c, Color.WHITE, 18));
        l.setPadding(dp(c, 16), dp(c, 16), dp(c, 16), dp(c, 16));
        return l;
    }

    public static LinearLayout.LayoutParams cardInner(Context c) {
        return new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        );
    }

    public static GradientDrawable rounded(Context c, int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    public static LinearLayout.LayoutParams matchWrap(Context c, int topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        );
        lp.topMargin = dp(c, topDp);
        return lp;
    }

    public static LinearLayout horizontal(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }
}
