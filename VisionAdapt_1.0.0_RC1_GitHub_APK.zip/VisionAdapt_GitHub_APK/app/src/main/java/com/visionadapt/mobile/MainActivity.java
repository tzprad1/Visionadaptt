package com.visionadapt.mobile;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import java.util.Calendar;
import java.util.Locale;

public class MainActivity extends Activity {
    private VisionProfileStore profileStore;
    private VisionProfile profile;
    private VisionSession session;
    private ProductStateStore productStore;
    private BillingManager entitlementBilling;

    private TextView status;
    private TextView preview;
    private TextView profileSummary;
    private TextView learningSummary;
    private TextView bridgeStatus;
    private TextView contextSummary;
    private TextView planStatus;
    private Button accessibilityButton;
    private Button startButton;
    private Button notGoodButton;
    private Button undoButton;
    private Button restoreButton;
    private Button contextButton;
    private Switch contextSwitch;
    private SeekBar fontBar;
    private SeekBar spacingBar;
    private SeekBar lineBar;
    private SeekBar contrastBar;
    private SeekBar brightnessBar;
    private boolean applyingControls;
    private VisionProfile manualBefore;
    private VisionContextMonitor contextMonitor;
    private Handler contextHandler;
    private boolean resumed;
    private final Runnable contextTicker = new Runnable() {
        @Override
        public void run() {
            refreshContextUi();
            if (contextHandler != null && resumed) contextHandler.postDelayed(this, 30000L);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        productStore = new ProductStateStore(this);
        if (!productStore.isOnboardingComplete()) {
            startActivity(new Intent(this, OnboardingActivity.class));
            finish();
            return;
        }
        profileStore = new VisionProfileStore(this);
        profile = profileStore.load();
        session = VisionRuntime.session();
        contextMonitor = new VisionContextMonitor(this, VisionRuntime.context());
        contextHandler = new Handler(Looper.getMainLooper());
        entitlementBilling = new BillingManager(this, (message, premiumActive, localizedPrice) ->
            runOnUiThread(() -> {
                refreshProductUi();
                updateContextMonitoring();
                VisionAccessibilityBridge.requestRefresh();
            }));

        setContentView(buildScreen());
        applyProfileToControls();
        syncSessionUi();
        refreshPreview();
        refreshBridgeStatus();
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        if (profileStore != null) {
            profile = profileStore.load();
            applyProfileToControls();
            syncSessionUi();
            refreshPreview();
            refreshBridgeStatus();
            updateContextMonitoring();
            refreshContextUi();
            refreshProductUi();
            if (entitlementBilling != null) entitlementBilling.start();
        }
    }

    @Override
    protected void onPause() {
        resumed = false;
        if (contextHandler != null) contextHandler.removeCallbacks(contextTicker);
        if (contextMonitor != null) contextMonitor.stop();
        super.onPause();
    }

    private View buildScreen() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        Ui.applySystemBarInsets(root, this, 20, 18, 20, 24);
        root.setBackgroundColor(Color.rgb(248, 248, 246));
        scroll.addView(root);

        root.addView(Ui.title(this, "VisionAdapt", 30));
        root.addView(Ui.body(this,
            "A tela se adapta à sua visão. Conforto e legibilidade; não é diagnóstico nem substitui avaliação oftalmológica.", 15),
            Ui.matchWrap(this, 8));

        LinearLayout productRow = Ui.horizontal(this);
        Button premiumButton = Ui.secondaryButton(this, "Premium");
        premiumButton.setOnClickListener(v -> startActivity(new Intent(this, PremiumActivity.class)));
        productRow.addView(premiumButton, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button privacyButton = Ui.secondaryButton(this, "Privacidade");
        privacyButton.setOnClickListener(v -> startActivity(new Intent(this, PrivacyActivity.class)));
        LinearLayout.LayoutParams privacyLp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        privacyLp.leftMargin = Ui.dp(this, 8);
        productRow.addView(privacyButton, privacyLp);
        root.addView(productRow, Ui.matchWrap(this, 16));

        planStatus = Ui.body(this, "", 13);
        root.addView(planStatus, Ui.matchWrap(this, 8));

        status = Ui.title(this, "VISÃO DESLIGADA", 17);
        root.addView(status, Ui.matchWrap(this, 24));

        startButton = Ui.primaryButton(this, "Iniciar visão");
        startButton.setOnClickListener(v -> toggleSession());
        root.addView(startButton, Ui.matchWrap(this, 10));

        notGoodButton = Ui.secondaryButton(this, "Ainda não está confortável");
        notGoodButton.setOnClickListener(v -> showABComparison());
        root.addView(notGoodButton, Ui.matchWrap(this, 10));

        LinearLayout safetyRow = Ui.horizontal(this);
        undoButton = Ui.button(this, "Desfazer");
        undoButton.setOnClickListener(v -> undoLastChange());
        safetyRow.addView(undoButton, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        restoreButton = Ui.button(this, "Início da sessão");
        restoreButton.setOnClickListener(v -> restoreSessionStart());
        safetyRow.addView(restoreButton, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        root.addView(safetyRow, Ui.matchWrap(this, 8));

        learningSummary = Ui.body(this, "", 14);
        root.addView(learningSummary, Ui.matchWrap(this, 8));

        root.addView(Ui.title(this, "Assistência contextual", 21), Ui.matchWrap(this, 24));
        root.addView(Ui.body(this,
            "O app combina tempo da sessão, luz ambiente e quantas vezes você pediu correção. Isso indica contexto de uso — não mede cansaço ocular nem faz diagnóstico.", 14),
            Ui.matchWrap(this, 4));

        contextSwitch = new Switch(this);
        contextSwitch.setText("Usar sugestões contextuais");
        contextSwitch.setChecked(profile.contextualAssistEnabled);
        contextSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked && !hasPremiumAccess()) {
                buttonView.setChecked(false);
                showPremiumRequired("A assistência contextual faz parte do Premium.");
                return;
            }
            profile.contextualAssistEnabled = isChecked;
            profileStore.save(profile);
            VisionAccessibilityBridge.requestRefresh();
            updateContextMonitoring();
            refreshContextUi();
        });
        root.addView(contextSwitch, Ui.matchWrap(this, 6));

        contextSummary = Ui.body(this, "", 14);
        root.addView(contextSummary, Ui.matchWrap(this, 6));

        contextButton = Ui.button(this, "Testar ajuste contextual");
        contextButton.setOnClickListener(v -> showContextComparison());
        root.addView(contextButton, Ui.matchWrap(this, 8));

        root.addView(Ui.title(this, "Ajuste manual", 21), Ui.matchWrap(this, 26));
        root.addView(Ui.body(this,
            "Se preferir, ajuste diretamente. Não é preciso saber o nome técnico do que incomoda.", 14),
            Ui.matchWrap(this, 4));

        fontBar = addSlider(root, "Tamanho do conteúdo", 90, 20);
        spacingBar = addSlider(root, "Espaço entre letras", 100, 16);
        lineBar = addSlider(root, "Espaço entre linhas", 110, 35);
        contrastBar = addSlider(root, "Contraste", 90, 30);
        brightnessBar = addSlider(root, "Luminosidade", 70, 35);

        SeekBar.OnSeekBarChangeListener listener = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser && !applyingControls && session.isActive()) {
                    readControlsIntoProfile();
                    refreshPreview();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
                if (session.isActive()) manualBefore = profile.copy();
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
                if (session.isActive()) {
                    readControlsIntoProfile();
                    boolean changed = manualBefore != null && !samePresentation(manualBefore, profile);
                    if (changed) {
                        session.recordCheckpoint(manualBefore);
                        session.noteUserCorrection();
                        VisionTuningEngine.onManualEdit(profile);
                        profileStore.save(profile);
                        VisionAccessibilityBridge.requestRefresh();
                    }
                    manualBefore = null;
                    syncSessionUi();
                    refreshPreview();
                }
            }
        };
        fontBar.setOnSeekBarChangeListener(listener);
        spacingBar.setOnSeekBarChangeListener(listener);
        lineBar.setOnSeekBarChangeListener(listener);
        contrastBar.setOnSeekBarChangeListener(listener);
        brightnessBar.setOnSeekBarChangeListener(listener);

        root.addView(Ui.title(this, "Prévia", 21), Ui.matchWrap(this, 28));
        preview = Ui.body(this,
            "Leia este texto sem forçar os olhos. O objetivo é que as letras pareçam naturais, estáveis e confortáveis. 1234567890", 18);
        preview.setPadding(Ui.dp(this, 16), Ui.dp(this, 16), Ui.dp(this, 16), Ui.dp(this, 16));
        preview.setBackgroundColor(Color.rgb(246, 246, 246));
        root.addView(preview, Ui.matchWrap(this, 10));

        profileSummary = Ui.body(this, "", 13);
        root.addView(profileSummary, Ui.matchWrap(this, 10));

        root.addView(Ui.title(this, "Usar sobre outros apps", 21), Ui.matchWrap(this, 28));
        root.addView(Ui.body(this,
            "Ative a camada opcional do Android para ter o botão flutuante 👁 VISÃO fora do app. Ela controla a ampliação oficial do sistema e a redução luminosa sem ler o conteúdo das telas.", 14),
            Ui.matchWrap(this, 4));

        bridgeStatus = Ui.body(this, "", 14);
        root.addView(bridgeStatus, Ui.matchWrap(this, 8));

        accessibilityButton = Ui.secondaryButton(this, "Configurar botão sobre outros apps");
        accessibilityButton.setOnClickListener(v -> {
            if (!hasPremiumAccess()) {
                showPremiumRequired("O botão sobre outros apps faz parte do Premium.");
                return;
            }
            showAccessibilityDisclosure();
        });
        root.addView(accessibilityButton, Ui.matchWrap(this, 8));

        root.addView(Ui.body(this,
            "Importante: um overlay comum não consegue mudar livremente fontes, espaçamento ou pixels internos de qualquer aplicativo. Esses ajustes completos continuam disponíveis no VisionAdapt e no navegador adaptativo.", 13),
            Ui.matchWrap(this, 6));

        root.addView(Ui.title(this, "Teste em páginas", 21), Ui.matchWrap(this, 28));

        EditText url = new EditText(this);
        url.setSingleLine(true);
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        url.setHint("https://exemplo.com • HTTPS");
        url.setText("https://www.wikipedia.org");
        root.addView(url, Ui.matchWrap(this, 8));

        Button openBrowser = Ui.button(this, "Abrir navegador adaptativo");
        openBrowser.setOnClickListener(v -> {
            String u = url.getText().toString().trim();
            if (u.startsWith("http://")) u = "https://" + u.substring(7);
            else if (!u.startsWith("https://")) u = "https://" + u.replaceFirst("^[a-zA-Z][a-zA-Z0-9+.-]*://", "");
            Intent i = new Intent(this, VisionBrowserActivity.class);
            i.putExtra("url", u);
            startActivity(i);
        });
        root.addView(openBrowser, Ui.matchWrap(this, 10));

        TextView note = Ui.body(this,
            "VisionAdapt 1.0 • aprendizado local, reversível e privacidade por padrão.", 14);
        root.addView(note, Ui.matchWrap(this, 26));

        return scroll;
    }

    private SeekBar addSlider(LinearLayout root, String label, int max, int initial) {
        root.addView(Ui.body(this, label, 15), Ui.matchWrap(this, 14));
        SeekBar s = new SeekBar(this);
        s.setMax(max);
        s.setProgress(initial);
        root.addView(s);
        return s;
    }

    private void toggleSession() {
        session.toggle(profile);
        updateContextMonitoring();
        syncSessionUi();
        refreshContextUi();
        refreshPreview();
        VisionAccessibilityBridge.requestRefresh();
    }

    private void syncSessionUi() {
        if (status == null) return;
        boolean active = session.isActive();
        status.setText(active ? "VISÃO ATIVA" : "VISÃO DESLIGADA");
        startButton.setText(active ? "Encerrar sessão" : "Iniciar visão");
        notGoodButton.setEnabled(active);
        undoButton.setEnabled(active && session.canUndo());
        restoreButton.setEnabled(active && session.canRestoreSessionStart());
        setManualControlsEnabled(active);
        refreshBridgeStatus();
        if (contextButton != null) contextButton.setEnabled(active && profile != null && (profile.contextualAssistEnabled || !hasPremiumAccess()));

        if (learningSummary != null && profile != null) {
            if (profile.totalComparisons() == 0) {
                learningSummary.setText(active
                    ? "O app ainda não aprendeu preferências. Use “Ainda não está confortável” quando quiser comparar duas versões."
                    : "Seu perfil fica salvo, mas a adaptação só começa quando você iniciar uma sessão.");
            } else {
                learningSummary.setText(String.format(Locale.US,
                    "Aprendizado local: %d comparações. O app lembra direções que você preferiu e continua testando alternativas. Histórico de desfazer nesta sessão: %d.",
                    profile.totalComparisons(), session.undoDepth()));
            }
        }
    }

    private void setManualControlsEnabled(boolean enabled) {
        if (fontBar == null) return;
        fontBar.setEnabled(enabled);
        spacingBar.setEnabled(enabled);
        lineBar.setEnabled(enabled);
        contrastBar.setEnabled(enabled);
        brightnessBar.setEnabled(enabled);
    }

    private void readControlsIntoProfile() {
        profile.fontScale = 0.80f + (fontBar.getProgress() / 100f);
        profile.letterSpacingEm = -0.03f + (spacingBar.getProgress() / 550f);
        profile.lineHeight = 1.10f + (lineBar.getProgress() / 100f);
        profile.contrast = 0.70f + (contrastBar.getProgress() / 100f);
        profile.brightness = 0.65f + (brightnessBar.getProgress() / 100f);
        profile.normalize();
    }

    private void applyProfileToControls() {
        if (fontBar == null || profile == null) return;
        applyingControls = true;
        fontBar.setProgress(Math.round((profile.fontScale - 0.80f) * 100));
        spacingBar.setProgress(Math.round((profile.letterSpacingEm + 0.03f) * 550));
        lineBar.setProgress(Math.round((profile.lineHeight - 1.10f) * 100));
        contrastBar.setProgress(Math.round((profile.contrast - 0.70f) * 100));
        brightnessBar.setProgress(Math.round((profile.brightness - 0.65f) * 100));
        applyingControls = false;
    }

    private void refreshPreview() {
        if (preview == null || profile == null) return;
        VisionProfile p = session.isActive() ? profile : new VisionProfile();
        preview.setTextSize(18f * p.fontScale);
        preview.setLetterSpacing(p.letterSpacingEm);
        preview.setLineSpacing(0, p.lineHeight);
        preview.setAlpha(VisionProfile.clamp(p.brightness, 0.65f, 1f));
        int base = Math.round(55f / VisionProfile.clamp(p.contrast, 0.7f, 1.6f));
        base = Math.max(0, Math.min(90, base));
        preview.setTextColor(Color.rgb(base, base, base));

        profileSummary.setText(String.format(Locale.US,
            "Ajustes atuais: tamanho %.0f%% • letras %.3fem • linhas %.2f • contraste %.2f • luminosidade %.2f\nTela externa: ampliação %.2fx • redução luminosa %.0f%%",
            profile.fontScale * 100f, profile.letterSpacingEm, profile.lineHeight,
            profile.contrast, profile.brightness,
            profile.externalMagnification, profile.externalDim * 100f));
        syncSessionUi();
    }

    private TextView comparisonCard(String label, VisionProfile p) {
        TextView t = Ui.body(this,
            label + "\n\nA leitura deve parecer clara, confortável e natural. Compare sem tentar descobrir o que mudou.",
            18f * p.fontScale);
        t.setLetterSpacing(p.letterSpacingEm);
        t.setLineSpacing(0, p.lineHeight);
        t.setPadding(Ui.dp(this, 16), Ui.dp(this, 16), Ui.dp(this, 16), Ui.dp(this, 16));
        t.setBackgroundColor(Color.rgb(246, 246, 246));
        t.setAlpha(VisionProfile.clamp(p.brightness, 0.65f, 1f));
        int base = Math.round(55f / VisionProfile.clamp(p.contrast, 0.7f, 1.6f));
        base = Math.max(0, Math.min(90, base));
        t.setTextColor(Color.rgb(base, base, base));
        return t;
    }

    private void showABComparison() {
        if (!session.isActive()) return;
        session.noteUserCorrection();
        refreshContextUi();

        final VisionTuningEngine.Proposal proposal = VisionTuningEngine.nextProposal(profile);
        final boolean candidateIsA = (System.nanoTime() & 1L) == 0L;
        final VisionProfile versionA = candidateIsA ? proposal.candidate : proposal.baseline;
        final VisionProfile versionB = candidateIsA ? proposal.baseline : proposal.candidate;
        final boolean[] seen = {true, false};

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(Ui.dp(this, 18), Ui.dp(this, 8), Ui.dp(this, 18), 0);

        TextView instruction = Ui.body(this,
            "A e B não dizem qual é a configuração atual. Veja as duas e escolha apenas pela facilidade de leitura.", 15);
        content.addView(instruction, Ui.matchWrap(this, 6));

        TextView card = comparisonCard("Versão A", versionA);
        content.addView(card, Ui.matchWrap(this, 10));

        LinearLayout switches = Ui.horizontal(this);
        Button showA = Ui.button(this, "Ver A");
        Button showB = Ui.button(this, "Ver B");
        switches.addView(showA, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        switches.addView(showB, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        content.addView(switches, Ui.matchWrap(this, 8));

        AlertDialog dialog = new AlertDialog.Builder(this)
            .setTitle("Qual ficou mais fácil de ler?")
            .setView(content)
            .setNegativeButton("A melhor", null)
            .setNeutralButton("Sem diferença", null)
            .setPositiveButton("B melhor", null)
            .create();

        showA.setOnClickListener(v -> {
            seen[0] = true;
            copyCardPresentation(card, "Versão A", versionA);
            updateDecisionEnabled(dialog, seen);
        });
        showB.setOnClickListener(v -> {
            seen[1] = true;
            copyCardPresentation(card, "Versão B", versionB);
            updateDecisionEnabled(dialog, seen);
        });

        dialog.setOnShowListener(d -> {
            updateDecisionEnabled(dialog, seen);
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v -> {
                applyBlindChoice(proposal, candidateIsA, true);
                dialog.dismiss();
            });
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                VisionTuningEngine.respond(profile, proposal, VisionTuningEngine.Response.SAME);
                profileStore.save(profile);
                refreshPreview();
                dialog.dismiss();
            });
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                applyBlindChoice(proposal, candidateIsA, false);
                dialog.dismiss();
            });
        });

        dialog.show();
    }

    private void applyBlindChoice(VisionTuningEngine.Proposal proposal, boolean candidateIsA, boolean choseA) {
        boolean choseCandidate = candidateIsA == choseA;
        if (choseCandidate) session.recordCheckpoint(profile);
        VisionTuningEngine.respond(profile, proposal,
            choseCandidate ? VisionTuningEngine.Response.BETTER : VisionTuningEngine.Response.WORSE);
        profileStore.save(profile);
        VisionAccessibilityBridge.requestRefresh();
        applyProfileToControls();
        refreshPreview();
    }

    private void copyCardPresentation(TextView target, String label, VisionProfile p) {
        target.setText(label + "\n\nA leitura deve parecer clara, confortável e natural. Compare sem tentar descobrir o que mudou.");
        target.setTextSize(18f * p.fontScale);
        target.setLetterSpacing(p.letterSpacingEm);
        target.setLineSpacing(0, p.lineHeight);
        target.setAlpha(VisionProfile.clamp(p.brightness, 0.65f, 1f));
        int base = Math.round(55f / VisionProfile.clamp(p.contrast, 0.7f, 1.6f));
        base = Math.max(0, Math.min(90, base));
        target.setTextColor(Color.rgb(base, base, base));
    }

    private void updateDecisionEnabled(AlertDialog dialog, boolean[] seen) {
        if (dialog == null || !dialog.isShowing()) return;
        boolean enabled = seen[0] && seen[1];
        dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setEnabled(enabled);
        dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setEnabled(enabled);
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setEnabled(enabled);
    }

    private void undoLastChange() {
        VisionProfile previous = session.popUndo();
        if (previous == null) return;
        profile = previous;
        profileStore.save(profile);
        VisionAccessibilityBridge.requestRefresh();
        applyProfileToControls();
        refreshPreview();
    }

    private void restoreSessionStart() {
        VisionProfile start = session.getSessionStartProfile();
        if (start == null) return;
        session.recordCheckpoint(profile);
        profile.adoptPresentationFrom(start);
        VisionTuningEngine.onManualEdit(profile);
        profileStore.save(profile);
        VisionAccessibilityBridge.requestRefresh();
        applyProfileToControls();
        refreshPreview();
    }

    private void updateContextMonitoring() {
        if (contextHandler == null || contextMonitor == null || profile == null) return;
        contextHandler.removeCallbacks(contextTicker);
        boolean shouldRun = resumed && session.isActive() && profile.contextualAssistEnabled && hasPremiumAccess();
        boolean serviceSuppliesSensor = VisionAccessibilityStatus.isEnabled(this);
        if (shouldRun) {
            if (serviceSuppliesSensor) contextMonitor.stop(); else contextMonitor.start();
            contextHandler.post(contextTicker);
        } else {
            contextMonitor.stop();
        }
    }

    private int currentHour() {
        return Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
    }

    private VisionContextEngine.Assessment currentContextAssessment() {
        return VisionContextEngine.assess(profile, session, VisionRuntime.context(),
            System.currentTimeMillis(), currentHour());
    }

    private void refreshContextUi() {
        if (contextSummary == null || profile == null || session == null) return;
        boolean active = session.isActive();
        if (!active) {
            contextSummary.setText("Contexto em espera. Ele começa a ser considerado quando você inicia uma sessão.");
            if (contextButton != null) contextButton.setEnabled(false);
            return;
        }
        if (!hasPremiumAccess()) {
            contextSummary.setText("Assistência contextual disponível no Premium. O ajuste manual e o A/B continuam gratuitos.");
            if (contextButton != null) { contextButton.setEnabled(true); contextButton.setText("Conhecer Premium"); }
            return;
        }
        if (!profile.contextualAssistEnabled) {
            contextSummary.setText("Assistência contextual desligada. Seus ajustes manuais e o A/B continuam funcionando normalmente.");
            if (contextButton != null) contextButton.setEnabled(false);
            return;
        }

        VisionContextEngine.Assessment a = currentContextAssessment();
        long minutes = a.elapsedMs / 60000L;
        String luxText = a.hasAmbientLux ? String.format(Locale.US, "%.0f lux", a.ambientLux) :
            (contextMonitor != null && contextMonitor.hasLightSensor() ? "luz aguardando leitura" : "sem sensor de luz");
        String level = a.level == VisionContextEngine.LoadLevel.ELEVATED ? "elevada" :
            (a.level == VisionContextEngine.LoadLevel.MODERATE ? "moderada" : "baixa");
        contextSummary.setText(String.format(Locale.US,
            "Carga contextual %s • %d min de sessão • %s • %d correções recentes.\n" +
            "Aprendizado contextual: %d ajudaram, %d não ajudaram, %d sem diferença.",
            level, minutes, luxText, a.recentCorrections,
            profile.contextAccepted, profile.contextRejected, profile.contextNeutral));

        VisionContextEngine.Proposal proposal = VisionContextEngine.nextProposal(profile, session,
            VisionRuntime.context(), System.currentTimeMillis(), currentHour());
        if (contextButton != null) {
            contextButton.setEnabled(proposal != null);
            contextButton.setText(proposal == null ? "Sem microajuste necessário agora" : "Testar microajuste sugerido");
        }
    }

    private void showContextComparison() {
        if (!hasPremiumAccess()) { showPremiumRequired("A assistência contextual faz parte do Premium."); return; }
        if (!session.isActive() || !profile.contextualAssistEnabled) return;
        final VisionContextEngine.Proposal proposal = VisionContextEngine.nextProposal(profile, session,
            VisionRuntime.context(), System.currentTimeMillis(), currentHour());
        if (proposal == null) {
            new AlertDialog.Builder(this)
                .setTitle("Contexto estável")
                .setMessage("Neste momento não há sinais contextuais suficientes para justificar outro microajuste. Você ainda pode usar “Ainda não está confortável” ou os controles manuais.")
                .setPositiveButton("OK", null)
                .show();
            return;
        }

        final boolean candidateIsA = (System.nanoTime() & 1L) == 0L;
        final VisionProfile versionA = candidateIsA ? proposal.candidate : proposal.baseline;
        final VisionProfile versionB = candidateIsA ? proposal.baseline : proposal.candidate;
        final boolean[] seen = {true, false};

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(Ui.dp(this, 18), Ui.dp(this, 8), Ui.dp(this, 18), 0);
        content.addView(Ui.body(this,
            "Este teste usa apenas sinais de contexto. A e B continuam cegas: escolha só pela facilidade de leitura.", 15),
            Ui.matchWrap(this, 6));

        TextView card = comparisonCard("Versão A", versionA);
        content.addView(card, Ui.matchWrap(this, 10));
        LinearLayout switches = Ui.horizontal(this);
        Button showA = Ui.button(this, "Ver A");
        Button showB = Ui.button(this, "Ver B");
        switches.addView(showA, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        switches.addView(showB, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        content.addView(switches, Ui.matchWrap(this, 8));

        AlertDialog dialog = new AlertDialog.Builder(this)
            .setTitle("O microajuste ajudou?")
            .setView(content)
            .setNegativeButton("A melhor", null)
            .setNeutralButton("Sem diferença", null)
            .setPositiveButton("B melhor", null)
            .create();

        showA.setOnClickListener(v -> {
            seen[0] = true;
            copyCardPresentation(card, "Versão A", versionA);
            updateDecisionEnabled(dialog, seen);
        });
        showB.setOnClickListener(v -> {
            seen[1] = true;
            copyCardPresentation(card, "Versão B", versionB);
            updateDecisionEnabled(dialog, seen);
        });

        dialog.setOnShowListener(d -> {
            updateDecisionEnabled(dialog, seen);
            dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(v -> {
                applyContextBlindChoice(proposal, candidateIsA, true);
                dialog.dismiss();
            });
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v -> {
                VisionContextEngine.respond(profile, VisionContextEngine.Response.SAME);
                profileStore.save(profile);
                refreshContextUi();
                dialog.dismiss();
            });
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
                applyContextBlindChoice(proposal, candidateIsA, false);
                dialog.dismiss();
            });
        });
        dialog.show();
    }

    private void applyContextBlindChoice(VisionContextEngine.Proposal proposal,
                                         boolean candidateIsA, boolean choseA) {
        boolean choseCandidate = candidateIsA == choseA;
        if (choseCandidate) {
            session.recordCheckpoint(profile);
            profile.adoptPresentationFrom(proposal.candidate);
            VisionContextEngine.respond(profile, VisionContextEngine.Response.BETTER);
        } else {
            VisionContextEngine.respond(profile, VisionContextEngine.Response.WORSE);
        }
        profileStore.save(profile);
        VisionAccessibilityBridge.requestRefresh();
        applyProfileToControls();
        refreshPreview();
        refreshContextUi();
    }

    private void refreshBridgeStatus() {
        if (bridgeStatus == null) return;
        if (!hasPremiumAccess()) {
            bridgeStatus.setText("Camada Android: Premium. O núcleo gratuito continua funcionando dentro do VisionAdapt.");
            if (accessibilityButton != null) accessibilityButton.setText("Desbloquear uso sobre outros apps");
            return;
        }
        boolean enabled = VisionAccessibilityStatus.isEnabled(this);
        bridgeStatus.setText(enabled
            ? "Camada Android: ATIVA. O botão flutuante aparece sobre outros apps."
            : "Camada Android: disponível. Toque abaixo para abrir as configurações de Acessibilidade.");
        if (accessibilityButton != null) accessibilityButton.setText("Configurar botão sobre outros apps");
    }

    private boolean hasPremiumAccess() {
        return productStore != null && productStore.hasPremiumAccess(System.currentTimeMillis());
    }

    private void refreshProductUi() {
        if (productStore == null || planStatus == null) return;
        if (productStore.isPremiumVerifiedActive(System.currentTimeMillis())) {
            planStatus.setText("Premium ativo • recursos contextuais e camada Android liberados.");
        } else {
            int days = productStore.trialDaysRemaining(System.currentTimeMillis());
            planStatus.setText(days > 0
                ? "Teste Premium ativo • " + days + " dia(s) restante(s). O núcleo manual continuará gratuito depois."
                : "Plano gratuito • ajuste manual, A/B e navegador adaptativo. Premium libera contexto e uso sobre outros apps.");
        }
        if (contextSwitch != null) {
            boolean access = hasPremiumAccess();
            contextSwitch.setEnabled(access);
            if (!access && contextSwitch.isChecked()) contextSwitch.setChecked(false);
        }
        refreshBridgeStatus();
    }


    private void showAccessibilityDisclosure() {
        new AlertDialog.Builder(this)
            .setTitle("Ativar controle visual sobre outros apps")
            .setMessage("O VisionAdapt usa o Serviço de Acessibilidade somente para mostrar o botão flutuante e controlar a ampliação do Android. Nesta versão, ele não lê textos de outros apps, não captura a tela e não acessa mensagens. Você pode desativar o serviço a qualquer momento nas configurações do Android.")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Abrir Acessibilidade", (d, w) -> {
                Intent settingsIntent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
                startActivity(settingsIntent);
            })
            .show();
    }

    private void showPremiumRequired(String reason) {
        new AlertDialog.Builder(this)
            .setTitle("Recurso Premium")
            .setMessage(reason + " O ajuste manual, a comparação A/B e o navegador adaptativo permanecem gratuitos.")
            .setNegativeButton("Agora não", null)
            .setPositiveButton("Ver Premium", (d, w) -> startActivity(new Intent(this, PremiumActivity.class)))
            .show();
    }

    @Override
    protected void onDestroy() {
        if (entitlementBilling != null) entitlementBilling.close();
        super.onDestroy();
    }

    private static boolean samePresentation(VisionProfile a, VisionProfile b) {
        if (a == null || b == null) return false;
        return Math.abs(a.fontScale - b.fontScale) < 0.0001f &&
            Math.abs(a.letterSpacingEm - b.letterSpacingEm) < 0.0001f &&
            Math.abs(a.lineHeight - b.lineHeight) < 0.0001f &&
            Math.abs(a.contrast - b.contrast) < 0.0001f &&
            Math.abs(a.brightness - b.brightness) < 0.0001f;
    }
}
