package com.visionadapt.mobile;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class OnboardingActivity extends Activity {
    private int step = 0;
    private TextView eyebrow;
    private TextView title;
    private TextView body;
    private TextView detail;
    private Button back;
    private Button next;

    private static final String[] TITLES = {
        "A tela passa a se adaptar a você",
        "Quando não estiver bom, você ensina",
        "Privacidade primeiro"
    };

    private static final String[] BODIES = {
        "Inicie uma sessão e o VisionAdapt aplica seu perfil de leitura. Você pode encerrar a qualquer momento e a apresentação volta ao normal.",
        "Toque em “Ainda não está confortável”. O app mostra duas versões cegas, você escolhe a mais fácil de ler e o motor refina a próxima tentativa.",
        "Seu perfil e o aprendizado ficam neste aparelho. A camada de acessibilidade não lê mensagens nem captura o conteúdo das telas nesta versão."
    };

    private static final String[] DETAILS = {
        "O núcleo gratuito inclui ajustes manuais, comparação A/B e navegador adaptativo.",
        "Você sempre pode desfazer ou voltar ao início da sessão. Não há diagnóstico médico nem promessa de substituir óculos.",
        "No build de teste, o Premium pode ser demonstrado por 7 dias. Na versão publicada, testes e ofertas são controlados pelo Google Play."
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        build();
        render();
    }

    private void build() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        Ui.applySystemBarInsets(root, this, 24, 20, 24, 20);
        root.setBackgroundColor(Color.rgb(248, 248, 246));

        eyebrow = Ui.body(this, "VISIONADAPT • PRIMEIRA CONFIGURAÇÃO", 13);
        root.addView(eyebrow, Ui.matchWrap(this, 0));
        title = Ui.title(this, "", 30);
        root.addView(title, Ui.matchWrap(this, 28));
        body = Ui.body(this, "", 18);
        root.addView(body, Ui.matchWrap(this, 18));

        LinearLayout card = Ui.card(this);
        detail = Ui.body(this, "", 15);
        card.addView(detail, Ui.cardInner(this));
        root.addView(card, Ui.matchWrap(this, 28));

        TextView progress = Ui.body(this, "3 passos. Sem conta obrigatória.", 14);
        root.addView(progress, Ui.matchWrap(this, 22));

        LinearLayout spacer = new LinearLayout(this);
        root.addView(spacer, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout buttons = Ui.horizontal(this);
        back = Ui.secondaryButton(this, "Voltar");
        back.setOnClickListener(v -> { if (step > 0) { step--; render(); } });
        buttons.addView(back, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        next = Ui.primaryButton(this, "Continuar");
        next.setOnClickListener(v -> {
            if (step < TITLES.length - 1) { step++; render(); }
            else finishOnboarding();
        });
        LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.4f);
        nlp.leftMargin = Ui.dp(this, 10);
        buttons.addView(next, nlp);
        root.addView(buttons);
        setContentView(root);
    }

    private void render() {
        eyebrow.setText("PASSO " + (step + 1) + " DE " + TITLES.length);
        title.setText(TITLES[step]);
        body.setText(BODIES[step]);
        detail.setText(DETAILS[step]);
        back.setEnabled(step > 0);
        next.setText(step == TITLES.length - 1
            ? (BuildConfig.DEV_LOCAL_PREMIUM_TRIAL ? "Começar teste de 7 dias" : "Começar")
            : "Continuar");
    }

    private void finishOnboarding() {
        new ProductStateStore(this).completeOnboardingAndStartTrialIfNeeded(System.currentTimeMillis());
        startActivity(new Intent(this, MainActivity.class));
        finish();
    }
}
