package com.visionadapt.mobile;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;

public class PrivacyActivity extends Activity {
    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        new ProductStateStore(this).markPrivacyViewed();

        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        Ui.applySystemBarInsets(root, this, 22, 18, 22, 24);
        root.setBackgroundColor(Color.rgb(248,248,246));
        scroll.addView(root);

        root.addView(Ui.title(this, "Privacidade e controle", 29));
        root.addView(Ui.body(this, "O VisionAdapt foi desenhado para funcionar com o mínimo de dados necessário.", 16), Ui.matchWrap(this, 10));

        addCard(root, "Fica neste aparelho", "Perfil visual, escolhas A/B, histórico de preferência e aprendizado contextual são armazenados localmente por SharedPreferences nesta versão.");
        addCard(root, "O que o sensor mede", "Quando a assistência contextual está ativa, o app pode ler a luz ambiente em lux e combinar isso com duração da sessão e quantidade de correções. Ele não chama isso de diagnóstico de cansaço ocular.");
        addCard(root, "Camada sobre outros apps", "O serviço de acessibilidade está configurado com canRetrieveWindowContent=false. Ele não solicita a árvore de textos de outros apps e não faz captura de tela nesta versão.");
        addCard(root, "Internet", "O navegador adaptativo usa internet para abrir páginas. O Google Play Billing usa a conexão do Google Play para consultar e processar a assinatura Premium.");
        addCard(root, "Saúde", "VisionAdapt é uma ferramenta de conforto e acessibilidade visual. Não diagnostica doenças, não mede acuidade visual clínica e não substitui avaliação oftalmológica.");

        Button reset = Ui.secondaryButton(this, "Apagar perfil e aprendizado visual");
        reset.setOnClickListener(v -> confirmReset());
        root.addView(reset, Ui.matchWrap(this, 24));

        Button close = Ui.primaryButton(this, "Voltar");
        close.setOnClickListener(v -> finish());
        root.addView(close, Ui.matchWrap(this, 10));
        setContentView(scroll);
    }

    private void addCard(LinearLayout root, String title, String body) {
        LinearLayout card = Ui.card(this);
        card.addView(Ui.title(this, title, 18), Ui.cardInner(this));
        LinearLayout.LayoutParams lp = Ui.cardInner(this);
        lp.topMargin = Ui.dp(this, 8);
        card.addView(Ui.body(this, body, 15), lp);
        root.addView(card, Ui.matchWrap(this, 14));
    }

    private void confirmReset() {
        new AlertDialog.Builder(this)
            .setTitle("Apagar aprendizado visual?")
            .setMessage("Isso restaura tamanho, espaçamento, contraste, luminosidade e toda a memória A/B. Sua assinatura e o onboarding não são apagados.")
            .setNegativeButton("Cancelar", null)
            .setPositiveButton("Apagar", (d, w) -> {
                getSharedPreferences("vision_profile", MODE_PRIVATE).edit().clear().apply();
                VisionRuntime.session().stop();
                VisionRuntime.context().reset();
                VisionAccessibilityBridge.requestRefresh();
                new AlertDialog.Builder(this).setMessage("Perfil visual restaurado.").setPositiveButton("OK", null).show();
            }).show();
    }
}
