package com.visionadapt.mobile;

/**
 * Pure data object that represents the user's preferred presentation profile.
 * Android persistence and tuning logic intentionally live outside this class.
 */
public class VisionProfile {
    public static final int SCHEMA_VERSION = 5;

    // Presentation values. Conservative bounds are enforced in normalize().
    public float fontScale = 1.00f;
    public float letterSpacingEm = 0.00f;
    public float lineHeight = 1.45f;
    public float contrast = 1.00f;
    public float brightness = 1.00f;

    // System-wide effects available through the optional accessibility bridge.
    public float externalMagnification = 1.00f;
    public float externalDim = 0.00f;

    // Contextual assistant preference and learning. This is not a medical fatigue score.
    public boolean contextualAssistEnabled = true;
    public int contextAccepted = 0;
    public int contextRejected = 0;
    public int contextNeutral = 0;

    // Search state used by the perceptual A/B engine.
    public int tuneAxis = 0;
    public int tuneDirection = 1;
    public int tunePrecision = 0;
    public int tuneAttemptsOnAxis = 0;

    // Non-medical interaction counters; no claim of visual improvement is derived from them.
    public int acceptedAdjustments = 0;
    public int rejectedAdjustments = 0;
    public int neutralAdjustments = 0;

    // Persistent learning evidence by presentation axis.
    // The engine uses preferredDirection to remember which direction previously helped.
    public final int[] axisBetter = new int[VisionTuningEngine.AXIS_COUNT];
    public final int[] axisWorse = new int[VisionTuningEngine.AXIS_COUNT];
    public final int[] axisSame = new int[VisionTuningEngine.AXIS_COUNT];
    public final int[] preferredDirection = new int[VisionTuningEngine.AXIS_COUNT];

    public VisionProfile copy() {
        VisionProfile v = new VisionProfile();
        v.copyAllFrom(this);
        return v;
    }

    /** Copies every persisted field, including search and learning memory. */
    public void copyAllFrom(VisionProfile other) {
        if (other == null) return;
        fontScale = other.fontScale;
        letterSpacingEm = other.letterSpacingEm;
        lineHeight = other.lineHeight;
        contrast = other.contrast;
        brightness = other.brightness;
        externalMagnification = other.externalMagnification;
        externalDim = other.externalDim;
        contextualAssistEnabled = other.contextualAssistEnabled;
        contextAccepted = other.contextAccepted;
        contextRejected = other.contextRejected;
        contextNeutral = other.contextNeutral;
        tuneAxis = other.tuneAxis;
        tuneDirection = other.tuneDirection;
        tunePrecision = other.tunePrecision;
        tuneAttemptsOnAxis = other.tuneAttemptsOnAxis;
        acceptedAdjustments = other.acceptedAdjustments;
        rejectedAdjustments = other.rejectedAdjustments;
        neutralAdjustments = other.neutralAdjustments;
        for (int i = 0; i < VisionTuningEngine.AXIS_COUNT; i++) {
            axisBetter[i] = other.axisBetter[i];
            axisWorse[i] = other.axisWorse[i];
            axisSame[i] = other.axisSame[i];
            preferredDirection[i] = other.preferredDirection[i];
        }
        normalize();
    }

    /** Copies only what is rendered. Search-state changes stay under the engine's control. */
    public void adoptPresentationFrom(VisionProfile other) {
        if (other == null) return;
        fontScale = other.fontScale;
        letterSpacingEm = other.letterSpacingEm;
        lineHeight = other.lineHeight;
        contrast = other.contrast;
        brightness = other.brightness;
        externalMagnification = other.externalMagnification;
        externalDim = other.externalDim;
        normalize();
    }

    public int totalComparisons() {
        return acceptedAdjustments + rejectedAdjustments + neutralAdjustments;
    }

    public int evidenceForAxis(int axis) {
        if (axis < 0 || axis >= VisionTuningEngine.AXIS_COUNT) return 0;
        return axisBetter[axis] + axisWorse[axis] + axisSame[axis];
    }

    public void normalize() {
        fontScale = clamp(fontScale, 0.80f, 1.70f);
        letterSpacingEm = clamp(letterSpacingEm, -0.03f, 0.18f);
        lineHeight = clamp(lineHeight, 1.10f, 2.20f);
        contrast = clamp(contrast, 0.70f, 1.60f);
        brightness = clamp(brightness, 0.65f, 1.35f);
        externalMagnification = clamp(externalMagnification, 1.00f, 2.50f);
        externalDim = clamp(externalDim, 0.00f, 0.60f);

        tuneAxis = Math.max(0, Math.min(VisionTuningEngine.AXIS_COUNT - 1, tuneAxis));
        tuneDirection = tuneDirection < 0 ? -1 : 1;
        tunePrecision = Math.max(0, Math.min(VisionTuningEngine.MAX_PRECISION, tunePrecision));
        tuneAttemptsOnAxis = Math.max(0, Math.min(2, tuneAttemptsOnAxis));

        acceptedAdjustments = nonNegative(acceptedAdjustments);
        rejectedAdjustments = nonNegative(rejectedAdjustments);
        neutralAdjustments = nonNegative(neutralAdjustments);
        contextAccepted = nonNegative(contextAccepted);
        contextRejected = nonNegative(contextRejected);
        contextNeutral = nonNegative(contextNeutral);
        for (int i = 0; i < VisionTuningEngine.AXIS_COUNT; i++) {
            axisBetter[i] = nonNegative(axisBetter[i]);
            axisWorse[i] = nonNegative(axisWorse[i]);
            axisSame[i] = nonNegative(axisSame[i]);
            preferredDirection[i] = preferredDirection[i] < 0 ? -1 : (preferredDirection[i] > 0 ? 1 : 0);
        }
    }

    private static int nonNegative(int value) {
        return Math.max(0, value);
    }

    public static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
