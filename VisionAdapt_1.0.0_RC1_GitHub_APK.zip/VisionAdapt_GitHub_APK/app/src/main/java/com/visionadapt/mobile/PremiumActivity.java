package com.visionadapt.mobile;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class PremiumActivity extends Activity implements BillingManager.Listener {
    private BillingManager billing;
    private ProductStateStore productStore;
    private TextView accessStatus;
    private TextView billingStatus;
    private Button buyButton;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        productStore = new ProductStateStore(this);
        billing = new BillingManager(this, this);
        setContentView(build());
        refreshAccess();
        billing.start();
    }

    private ScrollView build() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        Ui.applySystemBarInsets(root, this, 22, 18, 22, 24);
        root.setBackgroundColor(Color.rgb(248,248,246));
        scroll.addView(root);

        root.addView(Ui.body(this, "VISIONADAPT PREMIUM", 13));
        root.addView(Ui.title(this, "A adaptação continua quando o contexto muda", 28), Ui.matchWrap(this, 12));
        root.addView(Ui.body(this, "O núcleo de ajuste manual continua gratuito. Premium libera as camadas que acompanham a sessão e o uso fora do app.", 16), Ui.matchWrap(this, 12));

        LinearLayout card = Ui.card(this);
        card.addView(Ui.title(this, "Premium inclui", 20), Ui.cardInner(this));
        TextView features = Ui.body(this,
            "• Assistência contextual por tempo, luz e correções recentes\n\n" +
            "• Microajustes contextuais reversíveis\n\n" +
            "• Botão flutuante 👁 VISÃO sobre outros apps\n\n" +
            "• Ampliação e redução luminosa globais\n\n" +
            "• Evolução futura do motor adaptativo", 16);
        LinearLayout.LayoutParams flp = Ui.cardInner(this); flp.topMargin = Ui.dp(this, 10);
        card.addView(features, flp);
        root.addView(card, Ui.matchWrap(this, 22));

        accessStatus = Ui.title(this, "", 18);
        root.addView(accessStatus, Ui.matchWrap(this, 22));
        billingStatus = Ui.body(this, "Consultando Google Play…", 14);
        root.addView(billingStatus, Ui.matchWrap(this, 8));

        buyButton = Ui.primaryButton(this, "Assinar Premium");
        buyButton.setOnClickListener(v -> billing.purchase(this));
        root.addView(buyButton, Ui.matchWrap(this, 18));

        Button restore = Ui.secondaryButton(this, "Restaurar compra");
        restore.setOnClickListener(v -> billing.refreshPurchases());
        root.addView(restore, Ui.matchWrap(this, 10));

        Button close = Ui.secondaryButton(this, "Agora não");
        close.setOnClickListener(v -> finish());
        root.addView(close, Ui.matchWrap(this, 10));

        root.addView(Ui.body(this,
            "O preço e as ofertas são carregados diretamente do Google Play. Para publicação comercial ampla, a verificação de compras deve ser reforçada por backend seguro.", 12), Ui.matchWrap(this, 18));
        return scroll;
    }

    private void refreshAccess() {
        long now = System.currentTimeMillis();
        if (productStore.isPremiumVerifiedActive(now)) {
            accessStatus.setText("Premium ativo");
            buyButton.setEnabled(false);
            buyButton.setText("Assinatura ativa");
        } else {
            int days = productStore.trialDaysRemaining(now);
            accessStatus.setText(days > 0 ? "Teste Premium • " + days + " dia(s) restante(s)" : "Plano gratuito ativo");
            buyButton.setEnabled(true);
        }
    }

    @Override public void onBillingState(String message, boolean premiumActive, String localizedPrice) {
        runOnUiThread(() -> {
            billingStatus.setText(message);
            VisionAccessibilityBridge.requestRefresh();
            if (localizedPrice != null && !localizedPrice.isEmpty() && !premiumActive) {
                buyButton.setText("Assinar • " + localizedPrice);
            }
            refreshAccess();
        });
    }

    @Override protected void onResume() {
        super.onResume();
        if (billing != null) billing.refreshPurchases();
    }

    @Override protected void onDestroy() {
        if (billing != null) billing.close();
        super.onDestroy();
    }
}
