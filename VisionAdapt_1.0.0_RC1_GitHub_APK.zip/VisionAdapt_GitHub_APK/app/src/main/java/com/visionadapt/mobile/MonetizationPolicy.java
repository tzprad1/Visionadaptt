package com.visionadapt.mobile;

/** Pure business rules for premium access. Kept Android-free for testing. */
public final class MonetizationPolicy {
    public static final int TRIAL_DAYS = 7;
    public static final long DAY_MS = 24L * 60L * 60L * 1000L;
    public static final long TRIAL_MS = TRIAL_DAYS * DAY_MS;

    private MonetizationPolicy() {}

    public static boolean hasAccess(boolean premiumActive, long trialStartedAtMs, long nowMs) {
        if (premiumActive) return true;
        if (trialStartedAtMs <= 0L || nowMs < trialStartedAtMs) return false;
        return nowMs - trialStartedAtMs < TRIAL_MS;
    }

    public static long trialRemainingMs(long trialStartedAtMs, long nowMs) {
        if (trialStartedAtMs <= 0L || nowMs < trialStartedAtMs) return 0L;
        return Math.max(0L, TRIAL_MS - (nowMs - trialStartedAtMs));
    }

    public static int trialDaysRemaining(long trialStartedAtMs, long nowMs) {
        long remaining = trialRemainingMs(trialStartedAtMs, nowMs);
        if (remaining <= 0L) return 0;
        return (int) Math.ceil(remaining / (double) DAY_MS);
    }
}
