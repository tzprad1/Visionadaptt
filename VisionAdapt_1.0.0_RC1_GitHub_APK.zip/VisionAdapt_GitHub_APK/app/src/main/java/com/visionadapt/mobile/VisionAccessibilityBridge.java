package com.visionadapt.mobile;

import java.lang.ref.WeakReference;

/**
 * Same-process bridge between the Activities and the optional AccessibilityService.
 * It intentionally holds only a WeakReference so the service lifecycle remains owned by Android.
 */
public final class VisionAccessibilityBridge {
    private static WeakReference<VisionAccessibilityService> serviceRef = new WeakReference<>(null);

    private VisionAccessibilityBridge() {}

    static void attach(VisionAccessibilityService service) {
        serviceRef = new WeakReference<>(service);
    }

    static void detach(VisionAccessibilityService service) {
        VisionAccessibilityService current = serviceRef.get();
        if (current == service) serviceRef.clear();
    }

    public static void requestRefresh() {
        VisionAccessibilityService service = serviceRef.get();
        if (service != null) service.refreshFromSharedState();
    }
}
