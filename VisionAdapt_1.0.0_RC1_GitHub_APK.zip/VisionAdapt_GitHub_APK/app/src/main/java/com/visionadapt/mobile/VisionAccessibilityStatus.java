package com.visionadapt.mobile;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.content.Context;
import android.view.accessibility.AccessibilityManager;

import java.util.List;

/** Small read-only helper used by the app to explain whether the system bridge is enabled. */
public final class VisionAccessibilityStatus {
    private VisionAccessibilityStatus() {}

    public static boolean isEnabled(Context context) {
        if (context == null) return false;
        AccessibilityManager manager = (AccessibilityManager)
            context.getSystemService(Context.ACCESSIBILITY_SERVICE);
        if (manager == null || !manager.isEnabled()) return false;

        List<AccessibilityServiceInfo> services = manager.getEnabledAccessibilityServiceList(
            AccessibilityServiceInfo.FEEDBACK_ALL_MASK);
        String packageName = context.getPackageName();
        String className = VisionAccessibilityService.class.getName();
        for (AccessibilityServiceInfo info : services) {
            if (info == null || info.getResolveInfo() == null ||
                info.getResolveInfo().serviceInfo == null) continue;
            String p = info.getResolveInfo().serviceInfo.packageName;
            String n = info.getResolveInfo().serviceInfo.name;
            if (packageName.equals(p) && (className.equals(n) ||
                (n != null && n.endsWith(".VisionAccessibilityService")))) {
                return true;
            }
        }
        return false;
    }
}
