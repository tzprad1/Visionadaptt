package com.visionadapt.mobile;

/**
 * Perceptual A/B search engine.
 *
 * One presentation axis is explored at a time. A first rejection tests the
 * opposite direction on the same axis regardless of which direction was tried
 * first. A second rejection advances to the next axis. Repeated wins reduce the
 * step size so the search becomes progressively finer.
 */
public final class VisionTuningEngine {
    public static final int AXIS_COUNT = 5;
    public static final int MAX_PRECISION = 3;

    public enum Response {
        BETTER,
        WORSE,
        SAME
    }

    public enum Axis {
        FONT_SCALE("tamanho do conteúdo"),
        LETTER_SPACING("espaço entre letras"),
        LINE_HEIGHT("espaço entre linhas"),
        CONTRAST("contraste"),
        BRIGHTNESS("luminosidade");

        public final String userLabel;

        Axis(String userLabel) {
            this.userLabel = userLabel;
        }
    }

    public static final class Proposal {
        public final VisionProfile baseline;
        public final VisionProfile candidate;
        public final Axis axis;
        public final int direction;
        public final float delta;
        public final int precision;

        Proposal(VisionProfile baseline, VisionProfile candidate, Axis axis,
                 int direction, float delta, int precision) {
            this.baseline = baseline;
            this.candidate = candidate;
            this.axis = axis;
            this.direction = direction;
            this.delta = delta;
            this.precision = precision;
        }
    }

    private static final float[] BASE_STEPS = {
        0.080f, // font scale
        0.024f, // letter spacing em
        0.120f, // line height
        0.100f, // contrast
        0.080f  // brightness
    };

    private VisionTuningEngine() {}

    public static Proposal nextProposal(VisionProfile current) {
        if (current == null) current = new VisionProfile();
        VisionProfile baseline = current.copy();
        baseline.normalize();

        int startAxis = baseline.tuneAxis;
        int precision = baseline.tunePrecision;

        // Search every axis before giving up. This prevents an A/B comparison
        // where A and B are effectively identical because the current value is
        // already sitting on a bound.
        for (int offset = 0; offset < AXIS_COUNT; offset++) {
            int axisIndex = (startAxis + offset) % AXIS_COUNT;
            Axis axis = Axis.values()[axisIndex];
            int desiredDirection = offset == 0
                ? baseline.tuneDirection
                : preferredOrPositive(baseline, axisIndex);
            float step = stepFor(axis, precision);

            VisionProfile candidate = applyDelta(baseline, axis, desiredDirection, step);
            if (presentationDiffers(baseline, candidate)) {
                return new Proposal(baseline, candidate, axis, desiredDirection,
                    signedDelta(baseline, candidate, axis), precision);
            }

            int opposite = -desiredDirection;
            candidate = applyDelta(baseline, axis, opposite, step);
            if (presentationDiffers(baseline, candidate)) {
                return new Proposal(baseline, candidate, axis, opposite,
                    signedDelta(baseline, candidate, axis), precision);
            }
        }

        // With the current conservative bounds this path should be unreachable,
        // but returning a stable proposal is safer than throwing from the UI.
        Axis axis = Axis.values()[startAxis];
        return new Proposal(baseline, baseline.copy(), axis, baseline.tuneDirection, 0f, precision);
    }

    public static void respond(VisionProfile current, Proposal proposal, Response response) {
        if (current == null || proposal == null || response == null) return;
        int axisIndex = proposal.axis.ordinal();

        switch (response) {
            case BETTER:
                current.adoptPresentationFrom(proposal.candidate);
                current.acceptedAdjustments++;
                current.axisBetter[axisIndex]++;
                current.preferredDirection[axisIndex] = proposal.direction;
                current.tuneAxis = axisIndex;
                current.tuneDirection = proposal.direction;
                current.tunePrecision = Math.min(MAX_PRECISION, current.tunePrecision + 1);
                current.tuneAttemptsOnAxis++;
                if (current.tuneAttemptsOnAxis >= 2) {
                    advanceAxis(current);
                }
                break;

            case WORSE:
                current.rejectedAdjustments++;
                current.axisWorse[axisIndex]++;
                current.tuneAxis = axisIndex;

                // First rejection always explores the opposite direction. This
                // is intentionally independent of whether the first attempt was
                // positive or negative (learned preferences can start either way).
                if (current.tuneAttemptsOnAxis == 0) {
                    current.tuneDirection = -proposal.direction;
                    current.tuneAttemptsOnAxis = 1;
                } else {
                    // Both directions have now failed at this scale.
                    if (current.preferredDirection[axisIndex] == proposal.direction &&
                        current.axisWorse[axisIndex] > current.axisBetter[axisIndex]) {
                        current.preferredDirection[axisIndex] = 0;
                    }
                    current.tunePrecision = Math.min(MAX_PRECISION, current.tunePrecision + 1);
                    advanceAxis(current);
                }
                break;

            case SAME:
                current.neutralAdjustments++;
                current.axisSame[axisIndex]++;
                current.tunePrecision = Math.min(MAX_PRECISION, current.tunePrecision + 1);
                current.tuneAxis = axisIndex;
                advanceAxis(current);
                break;
        }

        current.normalize();
    }

    /** Manual edits create a new baseline but keep learned per-axis preference. */
    public static void onManualEdit(VisionProfile current) {
        if (current == null) return;
        current.tuneAxis = 0;
        current.tuneDirection = preferredOrPositive(current, 0);
        current.tunePrecision = 0;
        current.tuneAttemptsOnAxis = 0;
        current.normalize();
    }

    public static int preferredDirectionFor(VisionProfile current, Axis axis) {
        if (current == null || axis == null) return 1;
        return preferredOrPositive(current, axis.ordinal());
    }

    /** Compatibility helper for older code/tests. Prefer nextProposal(). */
    public static VisionProfile nextCandidate(VisionProfile current) {
        return nextProposal(current).candidate;
    }

    private static void advanceAxis(VisionProfile current) {
        current.tuneAxis = (current.tuneAxis + 1) % AXIS_COUNT;
        current.tuneDirection = preferredOrPositive(current, current.tuneAxis);
        current.tuneAttemptsOnAxis = 0;
    }

    private static int preferredOrPositive(VisionProfile current, int axisIndex) {
        if (current != null && axisIndex >= 0 && axisIndex < AXIS_COUNT) {
            int remembered = current.preferredDirection[axisIndex];
            if (remembered != 0) return remembered;
        }
        return 1;
    }

    private static float stepFor(Axis axis, int precision) {
        int p = Math.max(0, Math.min(MAX_PRECISION, precision));
        return BASE_STEPS[axis.ordinal()] / (1 << p);
    }

    private static VisionProfile applyDelta(VisionProfile source, Axis axis, int direction, float step) {
        VisionProfile c = source.copy();
        float d = step * (direction < 0 ? -1f : 1f);
        switch (axis) {
            case FONT_SCALE: c.fontScale += d; break;
            case LETTER_SPACING: c.letterSpacingEm += d; break;
            case LINE_HEIGHT: c.lineHeight += d; break;
            case CONTRAST: c.contrast += d; break;
            case BRIGHTNESS: c.brightness += d; break;
        }
        c.normalize();
        return c;
    }

    private static float signedDelta(VisionProfile a, VisionProfile b, Axis axis) {
        switch (axis) {
            case FONT_SCALE: return b.fontScale - a.fontScale;
            case LETTER_SPACING: return b.letterSpacingEm - a.letterSpacingEm;
            case LINE_HEIGHT: return b.lineHeight - a.lineHeight;
            case CONTRAST: return b.contrast - a.contrast;
            case BRIGHTNESS: return b.brightness - a.brightness;
            default: return 0f;
        }
    }

    public static boolean presentationDiffers(VisionProfile a, VisionProfile b) {
        if (a == null || b == null) return false;
        return Math.abs(a.fontScale - b.fontScale) > 0.0001f ||
            Math.abs(a.letterSpacingEm - b.letterSpacingEm) > 0.0001f ||
            Math.abs(a.lineHeight - b.lineHeight) > 0.0001f ||
            Math.abs(a.contrast - b.contrast) > 0.0001f ||
            Math.abs(a.brightness - b.brightness) > 0.0001f;
    }
}
