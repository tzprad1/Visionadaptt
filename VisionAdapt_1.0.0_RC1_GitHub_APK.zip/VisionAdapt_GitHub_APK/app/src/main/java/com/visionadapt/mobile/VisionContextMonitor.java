package com.visionadapt.mobile;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;

/** Low-rate ambient-light listener. It is registered only while contextual assistance is needed. */
public final class VisionContextMonitor implements SensorEventListener {
    private final SensorManager sensorManager;
    private final Sensor lightSensor;
    private final VisionContextState state;
    private boolean running;

    public VisionContextMonitor(Context context, VisionContextState state) {
        sensorManager = (SensorManager) context.getApplicationContext().getSystemService(Context.SENSOR_SERVICE);
        lightSensor = sensorManager == null ? null : sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT);
        this.state = state;
    }

    public boolean hasLightSensor() {
        return lightSensor != null;
    }

    public void start() {
        if (running || sensorManager == null || lightSensor == null) return;
        running = sensorManager.registerListener(this, lightSensor, SensorManager.SENSOR_DELAY_NORMAL);
    }

    public void stop() {
        if (!running || sensorManager == null) return;
        sensorManager.unregisterListener(this);
        running = false;
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (event == null || event.sensor == null || event.values == null || event.values.length == 0) return;
        if (event.sensor.getType() == Sensor.TYPE_LIGHT && state != null) {
            state.updateAmbientLux(event.values[0], System.currentTimeMillis());
        }
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // No calibration workflow is required for this conservative context signal.
    }
}
