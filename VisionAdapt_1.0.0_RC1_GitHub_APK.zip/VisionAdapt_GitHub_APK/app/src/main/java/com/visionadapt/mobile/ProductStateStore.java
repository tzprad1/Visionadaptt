package com.visionadapt.mobile;

import android.content.Context;
import android.content.SharedPreferences;

/** Stores onboarding/product state separately from the visual profile. */
public final class ProductStateStore {
    private static final String PREFS = "vision_product_state";
    private static final long PREMIUM_CACHE_MAX_AGE_MS = 7L * 24L * 60L * 60L * 1000L;
    private final SharedPreferences preferences;

    public ProductStateStore(Context context) {
        preferences = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public boolean isOnboardingComplete() {
        return preferences.getBoolean("onboardingComplete", false);
    }

    public void completeOnboardingAndStartTrialIfNeeded(long nowMs) {
        SharedPreferences.Editor e = preferences.edit().putBoolean("onboardingComplete", true);
        if (preferences.getLong("trialStartedAtMs", 0L) <= 0L) e.putLong("trialStartedAtMs", nowMs);
        e.apply();
    }

    public boolean isPremiumActive() {
        return preferences.getBoolean("premiumActive", false);
    }

    public void setPremiumActive(boolean active) {
        preferences.edit().putBoolean("premiumActive", active)
            .putLong("premiumCheckedAtMs", System.currentTimeMillis()).apply();
    }

    public long trialStartedAtMs() {
        return preferences.getLong("trialStartedAtMs", 0L);
    }

    public boolean hasPremiumAccess(long nowMs) {
        if (isPremiumVerifiedActive(nowMs)) return true;
        // Local trial exists only in DEBUG builds so clearing app data cannot be
        // used to reset Premium access in the release product. Production trial
        // eligibility and duration must be configured as a Google Play offer.
        return BuildConfig.DEV_LOCAL_PREMIUM_TRIAL &&
            MonetizationPolicy.hasAccess(false, trialStartedAtMs(), nowMs);
    }

    public boolean isPremiumVerifiedActive(long nowMs) {
        if (!isPremiumActive()) return false;
        long checked = preferences.getLong("premiumCheckedAtMs", 0L);
        return checked > 0L && nowMs >= checked && nowMs - checked <= PREMIUM_CACHE_MAX_AGE_MS;
    }

    public int trialDaysRemaining(long nowMs) {
        if (!BuildConfig.DEV_LOCAL_PREMIUM_TRIAL) return 0;
        return MonetizationPolicy.trialDaysRemaining(trialStartedAtMs(), nowMs);
    }

    public void markPrivacyViewed() {
        preferences.edit().putBoolean("privacyViewed", true).apply();
    }

    public boolean wasPrivacyViewed() {
        return preferences.getBoolean("privacyViewed", false);
    }
}
