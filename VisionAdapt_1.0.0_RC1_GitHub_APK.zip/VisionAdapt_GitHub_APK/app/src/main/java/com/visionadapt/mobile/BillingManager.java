package com.visionadapt.mobile;

import android.app.Activity;
import android.content.Context;

import com.android.billingclient.api.AcknowledgePurchaseParams;
import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.PendingPurchasesParams;
import com.android.billingclient.api.ProductDetails;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.QueryProductDetailsParams;
import com.android.billingclient.api.QueryPurchasesParams;

import java.util.Collections;
import java.util.List;

/**
 * Google Play Billing boundary for the Premium subscription.
 * Product configuration still has to be created in Play Console using PRODUCT_ID.
 * For a public launch, purchase verification should be moved to a secure backend.
 */
public final class BillingManager implements PurchasesUpdatedListener {
    public static final String PRODUCT_ID = "visionadapt_premium_monthly";
    public static final String PREFERRED_OFFER_TAG = "visionadapt_default";

    public interface Listener {
        void onBillingState(String message, boolean premiumActive, String localizedPrice);
    }

    private final BillingClient billingClient;
    private final ProductStateStore productStateStore;
    private Listener listener;
    private ProductDetails subscriptionDetails;
    private String localizedPrice = "";
    private boolean connecting;

    public BillingManager(Context context, Listener listener) {
        this.listener = listener;
        productStateStore = new ProductStateStore(context);
        billingClient = BillingClient.newBuilder(context.getApplicationContext())
            .setListener(this)
            .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
            .enableAutoServiceReconnection()
            .build();
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    public void start() {
        if (billingClient.isReady()) {
            refreshPurchases();
            queryProduct();
            return;
        }
        if (connecting) {
            notifyState("Conectando ao Google Play…");
            return;
        }
        connecting = true;
        notifyState("Conectando ao Google Play…");
        billingClient.startConnection(new BillingClientStateListener() {
            @Override public void onBillingSetupFinished(BillingResult billingResult) {
                connecting = false;
                if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                    refreshPurchases();
                    queryProduct();
                } else {
                    notifyState("Google Play indisponível: " + billingResult.getDebugMessage());
                }
            }

            @Override public void onBillingServiceDisconnected() {
                connecting = false;
                notifyState("Conexão com o Google Play interrompida. Ela será refeita automaticamente.");
            }
        });
    }

    public void refreshPurchases() {
        if (!billingClient.isReady()) return;
        QueryPurchasesParams params = QueryPurchasesParams.newBuilder()
            .setProductType(BillingClient.ProductType.SUBS)
            .build();
        billingClient.queryPurchasesAsync(params, (billingResult, purchases) -> {
            if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {
                boolean active = processPurchases(purchases);
                productStateStore.setPremiumActive(active);
                notifyState(active ? "Premium ativo." : "Assinatura não encontrada nesta conta.");
            } else {
                notifyState("Não foi possível restaurar compras: " + billingResult.getDebugMessage());
            }
        });
    }

    public void purchase(Activity activity) {
        if (activity == null) return;
        if (!billingClient.isReady()) {
            notifyState("Google Play ainda não está pronto.");
            start();
            return;
        }
        if (subscriptionDetails == null) {
            notifyState("Plano ainda não está disponível nesta instalação. Verifique o produto no Play Console.");
            queryProduct();
            return;
        }
        List<ProductDetails.SubscriptionOfferDetails> offers = subscriptionDetails.getSubscriptionOfferDetails();
        if (offers == null || offers.isEmpty()) {
            notifyState("Nenhuma oferta de assinatura está disponível para esta conta.");
            return;
        }
        ProductDetails.SubscriptionOfferDetails selectedOffer = selectOffer(offers);
        String offerToken = selectedOffer.getOfferToken();
        BillingFlowParams.ProductDetailsParams productParams =
            BillingFlowParams.ProductDetailsParams.newBuilder()
                .setProductDetails(subscriptionDetails)
                .setOfferToken(offerToken)
                .build();
        BillingFlowParams flowParams = BillingFlowParams.newBuilder()
            .setProductDetailsParamsList(Collections.singletonList(productParams))
            .build();
        BillingResult result = billingClient.launchBillingFlow(activity, flowParams);
        if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) {
            notifyState("Não foi possível abrir a compra: " + result.getDebugMessage());
        }
    }

    private void queryProduct() {
        if (!billingClient.isReady()) return;
        QueryProductDetailsParams.Product product = QueryProductDetailsParams.Product.newBuilder()
            .setProductId(PRODUCT_ID)
            .setProductType(BillingClient.ProductType.SUBS)
            .build();
        QueryProductDetailsParams params = QueryProductDetailsParams.newBuilder()
            .setProductList(Collections.singletonList(product))
            .build();
        billingClient.queryProductDetailsAsync(params, (billingResult, result) -> {
            if (billingResult.getResponseCode() != BillingClient.BillingResponseCode.OK) {
                notifyState("Não foi possível carregar o plano: " + billingResult.getDebugMessage());
                return;
            }
            List<ProductDetails> details = result.getProductDetailsList();
            subscriptionDetails = details == null || details.isEmpty() ? null : details.get(0);
            localizedPrice = extractPrice(subscriptionDetails);
            if (subscriptionDetails == null) {
                notifyState("Produto " + PRODUCT_ID + " ainda não foi encontrado no Google Play.");
            } else {
                notifyState(productStateStore.isPremiumActive() ? "Premium ativo." : "Plano pronto para assinar.");
            }
        });
    }


    private ProductDetails.SubscriptionOfferDetails selectOffer(List<ProductDetails.SubscriptionOfferDetails> offers) {
        if (offers == null || offers.isEmpty()) return null;
        for (ProductDetails.SubscriptionOfferDetails offer : offers) {
            List<String> tags = offer.getOfferTags();
            if (tags != null && tags.contains(PREFERRED_OFFER_TAG)) return offer;
        }
        return offers.get(0);
    }

    private String extractPrice(ProductDetails details) {
        if (details == null) return "";
        List<ProductDetails.SubscriptionOfferDetails> offers = details.getSubscriptionOfferDetails();
        if (offers == null || offers.isEmpty()) return "";
        ProductDetails.SubscriptionOfferDetails selectedOffer = selectOffer(offers);
        List<ProductDetails.PricingPhase> phases = selectedOffer.getPricingPhases().getPricingPhaseList();
        if (phases == null || phases.isEmpty()) return "";
        return phases.get(phases.size() - 1).getFormattedPrice();
    }

    @Override
    public void onPurchasesUpdated(BillingResult billingResult, List<Purchase> purchases) {
        int code = billingResult.getResponseCode();
        if (code == BillingClient.BillingResponseCode.OK && purchases != null) {
            boolean active = processPurchases(purchases) || productStateStore.isPremiumActive();
            productStateStore.setPremiumActive(active);
            notifyState(active ? "Compra confirmada. Premium ativo." : "Compra recebida, aguardando confirmação.");
        } else if (code == BillingClient.BillingResponseCode.USER_CANCELED) {
            notifyState("Compra cancelada. Nenhuma cobrança foi concluída por este fluxo.");
        } else {
            notifyState("Falha na compra: " + billingResult.getDebugMessage());
        }
    }

    private boolean processPurchases(List<Purchase> purchases) {
        boolean active = false;
        if (purchases == null) return false;
        for (Purchase purchase : purchases) {
            if (!purchase.getProducts().contains(PRODUCT_ID)) continue;
            if (purchase.getPurchaseState() == Purchase.PurchaseState.PURCHASED) {
                active = true;
                if (!purchase.isAcknowledged() && billingClient.isReady()) {
                    AcknowledgePurchaseParams params = AcknowledgePurchaseParams.newBuilder()
                        .setPurchaseToken(purchase.getPurchaseToken()).build();
                    billingClient.acknowledgePurchase(params, result -> {
                        if (result.getResponseCode() != BillingClient.BillingResponseCode.OK) {
                            notifyState("Premium reconhecido; confirmação com o Google Play pendente.");
                        }
                    });
                }
            }
        }
        return active;
    }

    private void notifyState(String message) {
        Listener l = listener;
        if (l != null) l.onBillingState(message, productStateStore.isPremiumActive(), localizedPrice);
    }

    public void close() {
        listener = null;
        connecting = false;
        billingClient.endConnection();
    }
}
