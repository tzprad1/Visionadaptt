package com.visionadapt.mobile;

/** Shared in-memory runtime state for all VisionAdapt screens. */
public final class VisionRuntime {
    private static final VisionSession SESSION = new VisionSession();
    private static final VisionContextState CONTEXT = new VisionContextState();

    private VisionRuntime() {}

    public static VisionSession session() {
        return SESSION;
    }

    public static VisionContextState context() {
        return CONTEXT;
    }
}
