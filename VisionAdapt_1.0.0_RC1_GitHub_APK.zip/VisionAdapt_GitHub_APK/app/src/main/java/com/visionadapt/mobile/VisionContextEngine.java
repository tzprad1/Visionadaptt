package com.visionadapt.mobile;

/**
 * Conservative context engine. It estimates contextual visual load, not eye fatigue or disease.
 * Inputs are session duration, recent user corrections, ambient light and local hour.
 */
public final class VisionContextEngine {
    public static final long LUX_FRESH_MS = 5L * 60L * 1000L;
    public static final long CORRECTION_WINDOW_MS = 10L * 60L * 1000L;

    public enum LoadLevel {
        LOW,
        MODERATE,
        ELEVATED
    }

    public enum Response {
        BETTER,
        WORSE,
        SAME
    }

    public static final class Assessment {
        public final long elapsedMs;
        public final int recentCorrections;
        public final boolean hasAmbientLux;
        public final float ambientLux;
        public final int localHour;
        public final float score;
        public final LoadLevel level;
        public final boolean lowLight;
        public final boolean brightLight;
        public final boolean longSession;
        public final boolean correctionPressure;

        Assessment(long elapsedMs, int recentCorrections, boolean hasAmbientLux,
                   float ambientLux, int localHour, float score, LoadLevel level,
                   boolean lowLight, boolean brightLight, boolean longSession,
                   boolean correctionPressure) {
            this.elapsedMs = elapsedMs;
            this.recentCorrections = recentCorrections;
            this.hasAmbientLux = hasAmbientLux;
            this.ambientLux = ambientLux;
            this.localHour = localHour;
            this.score = score;
            this.level = level;
            this.lowLight = lowLight;
            this.brightLight = brightLight;
            this.longSession = longSession;
            this.correctionPressure = correctionPressure;
        }
    }

    public static final class Proposal {
        public final VisionProfile baseline;
        public final VisionProfile candidate;
        public final Assessment assessment;

        Proposal(VisionProfile baseline, VisionProfile candidate, Assessment assessment) {
            this.baseline = baseline;
            this.candidate = candidate;
            this.assessment = assessment;
        }
    }

    private VisionContextEngine() {}

    public static Assessment assess(VisionProfile profile, VisionSession session,
                                    VisionContextState state, long nowMs, int localHour) {
        long elapsed = session == null ? 0L : session.getElapsedMs(nowMs);
        int corrections = session == null ? 0 : session.recentCorrectionCount(nowMs, CORRECTION_WINDOW_MS);
        boolean hasLux = state != null && state.hasFreshAmbientLux(nowMs, LUX_FRESH_MS);
        float lux = hasLux ? state.getAmbientLux() : -1f;

        float score = 0f;
        if (elapsed >= 90L * 60L * 1000L) score += 0.34f;
        else if (elapsed >= 60L * 60L * 1000L) score += 0.26f;
        else if (elapsed >= 35L * 60L * 1000L) score += 0.17f;
        else if (elapsed >= 20L * 60L * 1000L) score += 0.08f;

        if (corrections >= 4) score += 0.34f;
        else if (corrections == 3) score += 0.26f;
        else if (corrections == 2) score += 0.17f;
        else if (corrections == 1) score += 0.08f;

        boolean lowLight = hasLux && lux < 40f;
        boolean veryLowLight = hasLux && lux < 12f;
        boolean brightLight = hasLux && lux > 5000f;
        boolean veryBrightLight = hasLux && lux > 12000f;
        if (veryLowLight || veryBrightLight) score += 0.16f;
        else if (lowLight || brightLight) score += 0.09f;

        int hour = Math.max(0, Math.min(23, localHour));
        if (hour >= 22 || hour < 6) score += 0.07f;

        // If contextual suggestions were repeatedly rejected, require slightly stronger evidence.
        int accepted = profile == null ? 0 : profile.contextAccepted;
        int rejected = profile == null ? 0 : profile.contextRejected;
        float rejectionPenalty = rejected > accepted ? Math.min(0.10f, (rejected - accepted) * 0.02f) : 0f;
        score = clamp(score - rejectionPenalty, 0f, 1f);

        LoadLevel level = score >= 0.48f ? LoadLevel.ELEVATED :
            (score >= 0.24f ? LoadLevel.MODERATE : LoadLevel.LOW);
        boolean longSession = elapsed >= 35L * 60L * 1000L;
        boolean correctionPressure = corrections >= 2;

        return new Assessment(elapsed, corrections, hasLux, lux, hour, score, level,
            lowLight, brightLight, longSession, correctionPressure);
    }

    public static Proposal nextProposal(VisionProfile current, VisionSession session,
                                        VisionContextState state, long nowMs, int localHour) {
        if (current == null || session == null || !session.isActive() || !current.contextualAssistEnabled) {
            return null;
        }

        Assessment a = assess(current, session, state, nowMs, localHour);
        if (a.level == LoadLevel.LOW) return null;

        VisionProfile baseline = current.copy();
        VisionProfile candidate = current.copy();

        float trust = 1f;
        int net = current.contextAccepted - current.contextRejected;
        if (net >= 3) trust = 1.15f;
        else if (net <= -3) trust = 0.72f;
        else if (net < 0) trust = 0.86f;

        float intensity = (a.level == LoadLevel.ELEVATED ? 1.0f : 0.62f) * trust;

        if (a.longSession || a.correctionPressure) {
            candidate.fontScale += 0.030f * intensity;
            candidate.lineHeight += 0.045f * intensity;
            candidate.letterSpacingEm += 0.006f * intensity;
        }

        if (a.brightLight) {
            candidate.contrast += 0.040f * intensity;
        } else if (a.lowLight) {
            candidate.brightness -= 0.035f * intensity;
            candidate.externalDim += 0.040f * intensity;
        }

        if (a.correctionPressure || a.elapsedMs >= 60L * 60L * 1000L) {
            candidate.externalMagnification += 0.050f * intensity;
        }

        candidate.normalize();
        if (!differs(baseline, candidate)) return null;
        return new Proposal(baseline, candidate, a);
    }

    /**
     * Variant for the accessibility overlay. It guarantees that a suggested trial changes at
     * least one effect that is actually visible outside VisionAdapt (magnification or dimming).
     */
    public static Proposal nextExternalProposal(VisionProfile current, VisionSession session,
                                                VisionContextState state, long nowMs, int localHour) {
        Proposal base = nextProposal(current, session, state, nowMs, localHour);
        if (base == null) return null;
        VisionProfile candidate = base.candidate.copy();
        boolean externalChanged = Math.abs(candidate.externalMagnification - base.baseline.externalMagnification) > 0.0001f ||
            Math.abs(candidate.externalDim - base.baseline.externalDim) > 0.0001f;
        if (!externalChanged) {
            if (base.assessment.lowLight) candidate.externalDim += 0.04f;
            else candidate.externalMagnification += 0.05f;
            candidate.normalize();
        }
        if (!differs(base.baseline, candidate)) return null;
        return new Proposal(base.baseline, candidate, base.assessment);
    }

    public static void respond(VisionProfile profile, Response response) {
        if (profile == null || response == null) return;
        switch (response) {
            case BETTER: profile.contextAccepted++; break;
            case WORSE: profile.contextRejected++; break;
            case SAME: profile.contextNeutral++; break;
        }
        profile.normalize();
    }

    public static boolean differs(VisionProfile a, VisionProfile b) {
        if (a == null || b == null) return false;
        return Math.abs(a.fontScale - b.fontScale) > 0.0001f ||
            Math.abs(a.letterSpacingEm - b.letterSpacingEm) > 0.0001f ||
            Math.abs(a.lineHeight - b.lineHeight) > 0.0001f ||
            Math.abs(a.contrast - b.contrast) > 0.0001f ||
            Math.abs(a.brightness - b.brightness) > 0.0001f ||
            Math.abs(a.externalMagnification - b.externalMagnification) > 0.0001f ||
            Math.abs(a.externalDim - b.externalDim) > 0.0001f;
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
