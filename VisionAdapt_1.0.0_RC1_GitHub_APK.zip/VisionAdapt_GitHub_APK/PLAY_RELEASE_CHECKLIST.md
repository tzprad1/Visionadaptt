# Checklist de lançamento — VisionAdapt

## Obrigatório antes de subir para produção

- [ ] Confirmar que `com.visionadapt.mobile` está disponível e será o applicationId definitivo. Depois da publicação ele não deve ser trocado.
- [ ] Criar o app no Google Play Console.
- [ ] Configurar Play App Signing / chave de upload.
- [ ] Criar assinatura `visionadapt_premium_monthly`.
- [ ] Criar base plan mensal e, se desejado, oferta de trial de 7 dias.
- [ ] Marcar a oferta preferida com a tag `visionadapt_default`.
- [ ] Configurar preço por país no Play Console.
- [ ] Testar compra em faixa de teste interno com contas licenciadas.
- [ ] Publicar uma política de privacidade e inserir a URL no Play Console.
- [ ] Preencher Data safety com o comportamento real da versão publicada.
- [ ] Preencher a declaração de uso de AccessibilityService.
- [ ] Gravar o vídeo exigido pelo Play Console mostrando ativação e uso do serviço de acessibilidade.
- [ ] Explicar que o recurso serve a acessibilidade visual e que `canRetrieveWindowContent=false`.
- [ ] Não afirmar que o app diagnostica cansaço ocular, mede acuidade clínica ou substitui óculos/oftalmologista.
- [ ] Testar em pelo menos Android 8, 12, 14, 15 e 16 ou em aparelhos/emuladores equivalentes.
- [ ] Testar serviço de acessibilidade com Samsung/One UI, Android puro e outro fabricante quando possível.
- [ ] Validar compras/entitlements em backend seguro antes de escala comercial relevante.

## Comportamento atual do AccessibilityService

O serviço:

- mostra a cápsula flutuante do VisionAdapt;
- controla a ampliação oficial do Android;
- aplica uma camada visual neutra de redução luminosa;
- não solicita a árvore de conteúdo das janelas (`canRetrieveWindowContent=false`);
- não captura tela;
- não lê mensagens.

O uso deve continuar limitado a essa finalidade para que a declaração no Play Console permaneça verdadeira.
