# VisionAdapt 1.0.0-rc1

VisionAdapt é um app Android de adaptação visual controlada pelo usuário. A proposta desta versão é melhorar legibilidade e conforto de leitura sem afirmar correção clínica de refração, diagnóstico de fadiga ocular ou substituição de óculos/avaliação oftalmológica.

## Núcleo do produto

- sessão visual iniciada explicitamente pelo usuário;
- perfil local com tamanho, espaçamento entre letras, espaçamento entre linhas, contraste e luminosidade;
- comparação A/B cega com busca perceptual progressiva;
- memória por eixo do que ajudou e do que não ajudou;
- ajuste manual, desfazer e restauração do início da sessão;
- navegador adaptativo HTTPS;
- assistência contextual por duração da sessão, correções recentes, horário e luz ambiente em lux;
- serviço opcional de acessibilidade com botão flutuante, ampliação oficial do Android e redução luminosa;
- Google Play Billing para assinatura Premium;
- núcleo manual/A-B/navegador gratuito e camadas contextuais/externas no Premium.

## Build principal

- applicationId / namespace: `com.visionadapt.mobile`
- minSdk: 26
- compileSdk: 36
- targetSdk: 36
- AGP: 8.13.2
- Gradle: 8.13
- JDK: 17
- Play Billing: 9.1.0

Consulte `BUILD_AND_INSTALL.md`.

## AndroidIDE

O projeto principal está preparado para publicação atual (API 36). Como o AndroidIDE oficial foi arquivado e sua última linha declarava suporte explícito a AGP 8.2.x, existe uma configuração local em `androidide-compat/` para teste no celular. Ela não deve ser usada para uma nova publicação no Google Play em setembro de 2026.

## Premium

Produto esperado no Play Console:

`visionadapt_premium_monthly`

Tag preferida da oferta:

`visionadapt_default`

O build **debug** permite um trial local de 7 dias para desenvolvimento. O build **release** desativa esse trial local; ofertas e trials comerciais devem ser controlados pelo Google Play.

## Privacidade

- `allowBackup=false`;
- `usesCleartextTraffic=false`;
- `canRetrieveWindowContent=false` no AccessibilityService;
- sem captura de tela;
- sem leitura da árvore de conteúdo de outros apps;
- sem `addJavascriptInterface` no WebView;
- perfil visual salvo localmente;
- sensor físico utilizado: luz ambiente, quando a assistência contextual está ativa.

Consulte `PRIVACY_MODEL.md` e `PLAY_RELEASE_CHECKLIST.md`.

## Testes incluídos

Execute:

```bash
bash tools/run_core_smoke_test.sh
python tools/final_static_checks.py
```

O relatório desta entrega está em `TEST_REPORT_FINAL.md`.

## Limite técnico importante

Fora do próprio renderer/WebView, esta versão não promete reprocessar livremente os pixels internos de qualquer app de terceiros. A camada externa usa recursos oficiais do Android: magnificação e overlay visual não tocável. Transformações ópticas espaciais mais profundas pertencem a uma próxima geração do motor.
