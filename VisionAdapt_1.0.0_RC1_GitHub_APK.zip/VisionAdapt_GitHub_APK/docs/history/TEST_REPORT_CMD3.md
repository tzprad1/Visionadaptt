# VisionAdapt — relatório de testes do Comando 3

Data: 2026-09-06
Versão interna: `0.4.0-cmd3`

## Núcleo Java puro

Executado por `tools/run_core_smoke_test.sh`.

Resultado: **PASS**.

Cobertura comportamental deste passe:

- 500 comparações Better/Worse/Same mantendo todos os parâmetros dentro dos limites;
- soma de comparações consistente;
- primeira rejeição inverte direção no mesmo eixo;
- segunda rejeição avança de eixo;
- aceitação aplica candidato e grava evidência por eixo;
- resposta “Sem diferença” não muda apresentação;
- proposta em limite máximo continua produzindo alternativa útil;
- ajuste manual preserva memória aprendida;
- direção anteriormente preferida é reutilizada ao retornar ao eixo;
- arrays de evidência são copiados corretamente no perfil;
- sessão inicia/encerra corretamente;
- snapshot do início da sessão é independente do perfil mutável;
- checkpoint pode ser desfeito;
- histórico de undo limitado a 12 entradas.

## Persistência

O schema do perfil passou de 2 para 3. Perfis v1/v2 continuam sendo carregados; os novos campos de aprendizado começam neutros quando inexistentes.

## Interface revisada estaticamente

- A/B deixou de identificar “atual” e “tentativa”;
- A/B pode inverter qual versão ocupa cada letra;
- botões de decisão ficam bloqueados até o usuário visitar as duas versões;
- tela principal e navegador possuem Desfazer e Início da sessão;
- escolha vencedora candidata cria checkpoint antes de alterar o perfil;
- cancelar comparação no navegador reaplica o perfil vigente.

## Limitação deste ambiente

O APK completo ainda não foi compilado porque o toolchain Android completo não está instalado no ambiente atual. O núcleo independente de Android foi compilado e executado. A validação final em dispositivo permanece obrigatória no Comando 7.
