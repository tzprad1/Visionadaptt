# VisionAdapt — Test Report / Comando 5

## Núcleo puro

Executado por `tools/run_core_smoke_test.sh`.

Cobertura acumulada e nova:

- 500 ciclos mistos do motor perceptivo;
- inversão/refinamento/limites do A/B;
- sessão, snapshot e histórico de undo;
- bounds de efeitos externos;
- frescor/expiração do sinal de lux;
- janela temporal de correções recentes;
- cálculo de carga contextual por sinais combinados;
- geração de microajuste contextual;
- memória contextual Better/Worse/Same;
- proposta externa obrigatoriamente visível em magnificação/dimming;
- bloqueio de proposta quando assistência contextual está desativada;
- stress contextual de 300 iterações com diferentes lux/horários/respostas;
- bounds mantidos durante todo o stress.

Resultado: **PASS**.

## XML

Todos os XML do projeto foram parseados estruturalmente neste passe.

## Java Android

Foi feita checagem sintática com `javac` sem Android SDK. Os diagnósticos restantes são referências esperadas às classes `android.*`, ausentes neste container; não foram encontrados erros de parsing/sintaxe.

## Limitação desta validação

O ambiente desta etapa não contém `android.jar`, Android SDK nem Gradle Android completo. Portanto ainda não é possível declarar build/install do APK como aprovado. Essa validação permanece obrigatória no dispositivo/AndroidIDE antes da entrega do comando 7.
