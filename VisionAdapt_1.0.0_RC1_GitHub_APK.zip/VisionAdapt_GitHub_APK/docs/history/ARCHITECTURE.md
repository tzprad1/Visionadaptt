# VisionAdapt — arquitetura após o Comando 5

## Regra central

A sessão precisa ser iniciada pelo usuário. O VisionAdapt adapta apresentação e contexto, mas não declara diagnosticar fadiga ocular, acuidade ou doença.

## Camadas

### 1. Perfil
`VisionProfile` mantém apresentação, memória A/B, efeitos externos e aprendizado contextual.

### 2. Sessão
`VisionSession` mantém estado efêmero: início, snapshot, undo e timestamps das correções recentes. Nada disso religa a adaptação após uma abertura a frio.

### 3. Motor perceptivo
`VisionTuningEngine` altera um eixo por vez, testa os dois sentidos e refina o passo.

### 4. Motor contextual
`VisionContextEngine` recebe:

`tempo de sessão + correções recentes + lux + horário + memória de aceitação`

E produz:

`carga contextual → microajuste conservador`

A carga possui três estados: baixa, moderada e elevada. Ela é apenas heurística de contexto de uso.

### 5. Sensor
`VisionContextMonitor` escuta `Sensor.TYPE_LIGHT` em baixa frequência. Quando o AccessibilityService está ativo, ele é a fonte preferencial; Activities evitam duplicar o listener. Sem serviço, a Activity em primeiro plano assume a leitura.

### 6. Superfícies
- `MainActivity`: calibração, A/B e A/B contextual.
- `VisionBrowserActivity`: conteúdo web transformável, A/B e contexto.
- `VisionAccessibilityService`: magnificação/dimming reais do sistema e teste contextual externo.

## Reversibilidade

Toda mudança aceita que altera apresentação pode gerar checkpoint. Um teste contextual externo fica pendente até o usuário responder “Ajudou” ou “Não ajudou”. Rejeitar restaura exatamente o baseline anterior.

## Privacidade

`canRetrieveWindowContent=false`. A arquitetura não depende de captura de tela nem leitura de conteúdo de terceiros.

## Fluxo contextual

`SESSÃO ATIVA`
→ coletar sinais simples
→ calcular carga contextual
→ se baixa: não sugerir
→ se moderada/elevada: gerar microajuste
→ usuário compara/testa
→ registrar Better/Worse/Same
→ ajustar intensidade futura
→ salvar perfil

## Próximos passes

- Comando 6: UX final, onboarding, privacidade, monetização e robustez de produto.
- Comando 7: pente-fino integral, build em SDK real, instalação e validação de dispositivo.
