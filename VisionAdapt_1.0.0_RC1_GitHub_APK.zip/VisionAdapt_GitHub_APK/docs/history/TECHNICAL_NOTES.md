# Caderno técnico — VisionAdapt MVP 0.1

Data de início do protótipo: 2026-09-06.

## Problema técnico de produto

Reduzir a necessidade de o usuário adaptar continuamente seu comportamento visual à apresentação digital, permitindo que a própria apresentação seja modificada de forma persistente e corrigível pelo feedback perceptivo do usuário.

## Ciclo implementado

INICIAR SESSÃO → APLICAR PERFIL → USAR → “NÃO ESTÁ BOM” → GERAR CANDIDATO → COMPARAR A/B → ACEITAR/RECUSAR → SALVAR PERFIL → REAPLICAR.

## Parâmetros atuais

- escala de fonte/conteúdo
- espaçamento entre caracteres
- altura de linha
- contraste
- luminosidade

## Ideias deliberadamente deixadas para versões seguintes

- tempo desde o início da sessão como variável do perfil
- distância olho-tela
- luminosidade ambiente
- padrão de piscadas, somente com consentimento explícito
- perfis por tarefa (leitura, vídeo, trabalho)
- modelo de preferências com histórico de ajustes
- transformações espaciais específicas de imagem
- calibração monocular/binocular

Este arquivo é documentação de engenharia e não é um pedido de patente nem uma conclusão sobre patenteabilidade.

---

## Comando 1 — 2026-09-06

### Problemas encontrados e corrigidos

1. A tela principal mantinha uma cópia antiga do perfil após ajustes feitos no navegador.
2. A sessão era representada por estados separados em Activities diferentes.
3. O A/B do navegador podia ser solicitado com a adaptação desligada, sem produzir comparação visual válida.
4. Persistência e geração de candidato estavam acopladas ao objeto `VisionProfile`.
5. Sliders gravavam em `SharedPreferences` a cada pequeno movimento.

### Correções

- sessão compartilhada em memória;
- recarga de perfil no `onResume`;
- A/B e controles manuais condicionados à sessão ativa;
- persistência em `VisionProfileStore`;
- tuning em `VisionTuningEngine`;
- gravação manual ao terminar o gesto do slider;
- restrições básicas adicionais no WebView.

### Testes locais realizados

- parse de XML: aprovado;
- compilação do núcleo Java puro: aprovada;
- 20 ciclos de aceitação A/B mantendo limites: aprovados;
- sessão inicia desligada / start / stop: aprovado.

---

## Comando 2 — 2026-09-06

### Mudança central

O antigo gerador cíclico que apenas incrementava parâmetros foi substituído por uma busca perceptual bidirecional e progressiva.

### Propriedades do novo motor

- apenas um parâmetro muda por comparação;
- rejeitar uma direção faz o sistema testar a direção oposta;
- duas direções rejeitadas fazem o sistema abandonar temporariamente aquele eixo;
- aceitar uma mudança reduz o tamanho dos próximos passos;
- “Igual” não altera o perfil;
- os deltas são sempre limitados às faixas conservadoras do MVP;
- candidatos que bateriam no limite são redirecionados para uma alternativa efetivamente diferente;
- um ajuste manual reinicia a exploração porque passa a existir uma nova baseline humana.

### Memória persistida adicionada

- eixo de tuning;
- direção;
- precisão;
- tentativas no eixo;
- contadores Better/Worse/Same.

Esses contadores descrevem escolhas de interface. **Não representam melhora clínica nem percentual de acuidade visual.**

### Comparação dentro do navegador

A e B agora podem ser alternados várias vezes na página real antes da decisão. Isso evita depender da memória visual imediata do usuário e torna o feedback mais confiável.

### Renderização

O CSS adaptativo passa a atualizar o mesmo elemento `<style>` em vez de removê-lo e recriá-lo. O objetivo é reduzir flicker durante A/B e preparar transições mais suaves.

### Testes locais

Ver `TEST_REPORT_CMD2.md`.

---

## Comando 3 — 2026-09-06

### Objetivo

Reduzir o esforço cognitivo da calibração e fazer o sistema aprender preferências sem induzir a escolha do usuário.

### Comparação cega

A interface deixou de apresentar “A atual” e “B tentativa”. Baseline e candidata são mapeadas para A/B de maneira pseudoaleatória em cada comparação. A decisão só fica disponível depois de o usuário ter visualizado as duas versões.

### Memória por eixo

O schema 3 adicionou quatro vetores de cinco posições:

- `axisBetter`;
- `axisWorse`;
- `axisSame`;
- `preferredDirection`.

Uma aceitação grava a direção vencedora do eixo. Quando o motor volta a esse eixo, a direção aprendida é usada como primeira hipótese. Isso é memória de interface, não inferência médica.

### Reversibilidade

`VisionSession` mantém snapshot do perfil no início da sessão e uma pilha limitada a 12 checkpoints. Isso cobre aceitação A/B e ajustes manuais. O usuário pode desfazer a última alteração ou restaurar a apresentação do início da sessão sem apagar a memória aprendida.

### Decisão de privacidade

Toda essa memória permanece local em `SharedPreferences` nesta etapa. Não há conta, nuvem, câmera nem coleta biométrica no Comando 3.

### Testes

Ver `TEST_REPORT_CMD3.md`.

---

## Comando 4 — 2026-09-06

### Objetivo

Levar o VisionAdapt para fora do navegador interno sem fingir que um overlay consegue reescrever os pixels ou o layout de qualquer aplicativo Android.

### Camada Android implementada

Foi adicionado `VisionAccessibilityService`, opt-in e ativado exclusivamente pelo usuário nas configurações de Acessibilidade do Android.

O serviço oferece:

- cápsula flutuante `👁 VISÃO` sobre outros apps;
- início/encerramento manual da mesma `VisionSession` usada pelo aplicativo;
- controle de ampliação do sistema via `AccessibilityService.MagnificationController`;
- redução luminosa por overlay não-interativo e não-focável;
- controles manuais `+/-`;
- desfazer compartilhado com a sessão;
- restauração do perfil do início da sessão;
- reset apenas dos efeitos externos;
- retorno direto ao app principal.

### Privacidade deliberada

A configuração do serviço define `canRetrieveWindowContent=false`. O Comando 4 não usa `getRootInActiveWindow`, não captura screenshots e não persiste texto, imagens ou nomes de apps utilizados. O serviço solicita somente a capacidade necessária para controlar a magnificação e desenhar sua própria interface de acessibilidade.

### Limite técnico explicitado

A camada externa não promete alterar fontes, letter-spacing, line-height ou aplicar deconvolução aos pixels internos de apps de terceiros. Sem uma pipeline de captura/renderização autorizada, esses recursos permanecem no renderer do VisionAdapt/WebView. Isso evita uma UX enganosa e mantém o MVP tecnicamente defensável.

### Perfil schema 4

Novos campos locais:

- `externalMagnification` — 1.00x a 2.50x;
- `externalDim` — 0 a 60%.

Ambos participam de `copy`, `normalize`, snapshots da sessão, undo e restauração.


## Comando 5 — contexto adaptativo

- Adicionado `VisionContextEngine` puro e testável.
- Sinais: duração da sessão, correções em janela de 10 min, lux fresco por até 5 min e hora local.
- A carga é heurística de produto, não métrica clínica.
- Sugestões rejeitadas aumentam conservadorismo futuro.
- Sugestões aceitas podem aumentar levemente a intensidade, sempre dentro dos bounds do perfil.
- O modo externo usa `nextExternalProposal()` para garantir que o teste altere magnificação ou dimming, que são os efeitos realmente disponíveis fora do renderer próprio.
- O sensor de luz é opcional e a ausência dele não impede o app de funcionar.
