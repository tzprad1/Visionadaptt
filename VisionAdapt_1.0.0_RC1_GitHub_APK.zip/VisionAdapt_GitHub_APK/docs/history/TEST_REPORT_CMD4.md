# VisionAdapt — Test Report — Comando 4

Data: 2026-09-06
Versão: 0.5.0-cmd4

## Testes executados neste ambiente

### Núcleo Java puro

`tools/run_core_smoke_test.sh`

Resultado: **PASS**

Cobertura acumulada:

- 500 ciclos mistos Better/Worse/Same do motor A/B;
- limites dos cinco eixos internos;
- aprendizado de direção por eixo;
- ciclo de vida da sessão;
- snapshot do início da sessão;
- undo limitado a 12 checkpoints;
- limites de magnificação externa: 1.00x–2.50x;
- limites de dim externo: 0–60%;
- cópia independente dos campos externos;
- restauração dos campos externos via perfil.

### XML

Foram parseados com sucesso:

- `AndroidManifest.xml`;
- `res/xml/vision_accessibility_service.xml`;
- `styles.xml`;
- `strings.xml`.

Resultado: **PASS**

### Parse sintático Java

Todos os fontes Java foram submetidos ao `javac` disponível. Como o ambiente não contém `android.jar`, são esperados erros de resolução para classes `android.*`. Não foram detectados erros de parser como `';' expected`, `illegal start`, `unclosed`, `reached end of file` ou equivalentes.

Resultado de sintaxe: **PASS**

## Verificações que exigem dispositivo/SDK Android real

Permanecem obrigatórias para o Comando 7:

1. build Gradle integral com Android SDK 34;
2. instalação do APK em dispositivo Android;
3. ativação/desativação do AccessibilityService;
4. adição/remoção/reordenação dos overlays pelo WindowManager;
5. comportamento da ampliação em One UI/Android 16 no aparelho-alvo;
6. interação com teclado, rotação, split-screen e apps fullscreen;
7. ausência de toque bloqueado pela camada de dim;
8. limpeza da magnificação e overlays ao desativar o serviço/processo;
9. teste de desempenho e consumo de bateria.

## Resultado do passe

O Comando 4 fecha a primeira integração real com o Android sem introduzir captura de tela nem prometer transformação arbitrária de apps de terceiros.
