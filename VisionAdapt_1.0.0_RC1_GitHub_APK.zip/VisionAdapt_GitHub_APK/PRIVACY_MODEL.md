# VisionAdapt — modelo de privacidade

## Dados locais

O perfil visual e a aprendizagem perceptiva ficam no aparelho em `SharedPreferences` nesta versão. O backup automático do Android está desativado.

## Sensor

A assistência contextual pode utilizar `TYPE_LIGHT` para ler iluminação ambiente em lux. O sensor é registrado somente enquanto a assistência contextual precisa dele e é desregistrado ao sair/pausar a superfície correspondente.

## AccessibilityService

Configuração atual:

- `isAccessibilityTool=true`;
- `canRetrieveWindowContent=false`;
- `canControlMagnification=true`;
- eventos limitados a mudança de janela;
- sem `getRootInActiveWindow`;
- sem screenshot;
- sem leitura de mensagens ou textos de terceiros.

O nome do pacote da janela pode ser observado pelo sistema apenas para esconder o próprio botão flutuante quando o VisionAdapt está na frente. Ele não é persistido pelo app.

## WebView

- somente navegação HTTPS;
- mixed content bloqueado;
- acesso a arquivos/conteúdo local desativado;
- geolocalização desativada;
- Safe Browsing ativado quando disponível;
- sem `addJavascriptInterface`.

## Saúde

O app descreve seus sinais como **contexto de uso**, não como diagnóstico. Não mede acuidade visual clínica, doença ocular ou fadiga ocular clínica e não substitui oftalmologista ou prescrição de lentes.
