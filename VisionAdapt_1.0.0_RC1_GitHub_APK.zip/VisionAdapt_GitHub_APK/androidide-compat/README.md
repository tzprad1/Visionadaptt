# AndroidIDE compatibility mode

The official AndroidIDE project is archived and its last release explicitly added AGP 8.2.x support. The Play-ready VisionAdapt project now targets Android 16 / API 36 and therefore uses AGP 8.13.2.

If the current AndroidIDE installation cannot sync AGP 8.13.2, temporarily copy these two compatibility files over the project root/app build files for a LOCAL DEBUG BUILD ONLY:

- `androidide-compat/build.gradle` -> `build.gradle`
- `androidide-compat/app.build.gradle` -> `app/build.gradle`

This compatibility build targets API 34 and is NOT suitable for a new Google Play submission in September 2026. Keep the main build files for release/CI.
