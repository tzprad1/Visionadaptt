# VisionAdapt 1.0.0-rc1 — relatório final

Data do pente-fino: 2026-09-07

## Correções encontradas no Comando 7

1. Corrigida a inversão A/B quando a direção previamente aprendida era negativa e o usuário a rejeitava.
2. O gerador de propostas passou a percorrer todos os eixos para evitar A/B idêntico em valores de limite.
3. O trial Premium local foi restrito a debug; release depende do Google Play.
4. Entitlement Premium passou a ser atualizado ao usar a tela principal e recebe validade local limitada.
5. Build principal atualizado para API 36 / AGP 8.13.2.
6. Criada configuração separada de teste local para AndroidIDE antigo.
7. Adicionado tratamento de insets para edge-to-edge em Android 15/16.
8. Painel flutuante tornou-se rolável e a cápsula é mantida dentro dos limites da tela.
9. WebView endurecida para HTTPS, Safe Browsing, sem geolocalização, sem mixed content e sem acesso local.
10. Adicionada divulgação clara antes de abrir as configurações de AccessibilityService.
11. Namespace e applicationId consolidados em `com.visionadapt.mobile`.
12. Removidos textos internos de “passe/comando” da interface final.

## Testes executados neste ambiente

- teste de núcleo Java: PASS;
- 500 ciclos de treino A/B com bounds: PASS;
- teste de rejeição positiva -> direção oposta: PASS;
- teste de rejeição de preferência negativa -> direção positiva: PASS;
- teste de limites gerando comparação não idêntica: PASS;
- ciclo de sessão: PASS;
- undo e snapshot inicial: PASS;
- limite do histórico: PASS;
- stress contextual: PASS;
- bounds de ampliação/dimming: PASS;
- regras puras do trial: PASS;
- parse estrutural de todos os XML: PASS;
- checks estáticos de targetSdk/compileSdk/Billing/privacidade: PASS;
- busca de erros sintáticos pelo `javac` disponível: nenhum erro de parser detectado.

## O que não pôde ser executado aqui

Este ambiente não possui Android SDK/`android.jar`/Gradle completos, portanto **não foi possível gerar e instalar fisicamente o APK nesta sessão**. Para fechar a validação binária, o projeto inclui:

- configuração Play-ready;
- workflow GitHub Actions que instala SDK 36 e gera APK/AAB;
- configuração AndroidIDE compatível para teste local.

A primeira compilação Android integral deve ser tratada como gate antes da publicação pública.
